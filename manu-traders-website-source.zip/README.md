# MANU Traders — Website

Official website for **MANU Traders** — *Growing Together With Farmers.*
Built with Next.js 16 (App Router), TypeScript, Tailwind CSS v4, Framer Motion, GSAP ScrollTrigger and Lenis.

## Run locally

```bash
npm install
npm run dev        # http://localhost:3000
npm run build && npm start   # production build
npm run lint
```

Copy `.env.example` to `.env.local` and set `NEXT_PUBLIC_SITE_URL` before deploying.

## Before launch — replace placeholders

All business details live in **one file: `data/company.ts`**. Anything in `[brackets]` or with `XXXX` is a placeholder.

| What | Where |
| --- | --- |
| Phone, WhatsApp number, email, address, hours, Google Maps link/embed, social links | `data/company.ts` |
| Statistics (`XX+`) — set `value` to a real number to enable the count-up | `data/stats.ts` |
| Farmer testimonials (currently marked **Sample**) | `data/testimonials.ts` |
| Services (set `enabled: false` to hide one) | `data/services.ts` |
| Coconut care section (set `enabled: false` to hide) | `data/coconut.ts` |
| Product categories, tags and images | `data/products.ts` |
| Photos (placeholders from the Stitch design) | `public/images/*.webp` — keep filenames or update paths in `data/` |
| Logo (SVG redraw of the Stitch emblem) | `components/ui/Logo.tsx`, `app/icon.svg`, `app/apple-icon.png` |
| Legal "last updated" date | `data/company.ts → legalLastUpdated` |
| Privacy Policy / Terms text | `app/privacy-policy/page.tsx`, `app/terms/page.tsx` |

LocalBusiness structured data is emitted automatically **only once a real address is set** in `data/company.ts`.

## Enquiry form

`lib/enquiry.ts` validates the form (Indian 10-digit mobile, required fields). No backend is connected:

- If `NEXT_PUBLIC_ENQUIRY_ENDPOINT` is set, the form POSTs JSON `{ name, mobile, location, crop, message, source }` to it.
- Otherwise, after validation the visitor gets a **Send on WhatsApp** button with the enquiry prefilled.

## Structure

```
app/                 routes, metadata, sitemap, robots, manifest, icons, legal pages
components/layout/   Navbar, MobileMenu, Footer, WhatsAppButton, Providers, LegalPage
components/sections/ Hero, About, Products, Coconut, Cinematic, WhyChooseUs, GrowthStory,
                     FarmJourney, Services, Stats, Testimonials, ParallaxBrand, ContactCTA, Contact
components/animations/ Reveal, TextReveal, ParallaxImage, CountUp, AmbientParticles,
                     SmoothScroll (Lenis), CustomCursor
components/ui/       Button, SectionLabel, SectionHeader, Logo, JsonLd
data/                all editable content and company config
lib/                 company helpers, motion tokens, schema builders, enquiry logic
hooks/               media queries, scroll state, active section
```

## Motion & accessibility notes

- `prefers-reduced-motion` disables Lenis, parallax, the GSAP growth timeline, autoplay and CSS animations.
- The crop-growth graphic (`GrowthStory`) lazy-loads GSAP only when the section approaches the viewport;
  without JS it shows the fully grown plant.
- Custom cursor is desktop-only (fine pointer) and never hides the native cursor.
- Fonts (Outfit + Inter) are self-hosted in `app/fonts` — no external font requests.

## Deploy

Works on Vercel, Hostinger Node.js hosting or any Node 20+ server (`npm run build && npm start`).
Set `NEXT_PUBLIC_SITE_URL` in the hosting environment.
