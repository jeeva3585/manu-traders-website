import type { Metadata } from "next";
import { LegalPage, type LegalSection } from "@/components/layout/LegalPage";
import { company } from "@/data/company";
import { formattedAddress } from "@/lib/company";

export const metadata: Metadata = {
  title: "Terms & Conditions",
  description: `General terms for using the ${company.companyName} website.`,
  alternates: { canonical: "/terms" },
};

const name = company.companyName;

/** Generic, editable website terms. Do not add claims of certification or compliance unless confirmed. */
const sections: LegalSection[] = [
  {
    id: "website-information",
    title: "Website Information",
    body: (
      <p>
        This website provides general information about {name} and the agricultural products and services we offer.
        We try to keep the information accurate and up to date, but it may change without notice and may contain
        errors or omissions.
      </p>
    ),
  },
  {
    id: "product-information",
    title: "Product Information",
    body: (
      <p>
        Product names, descriptions and images on this website are for general reference only. Images may be
        illustrative and may not show the exact product, brand or packaging available. Please confirm product
        details, specifications and pricing with us before purchase.
      </p>
    ),
  },
  {
    id: "availability",
    title: "Availability",
    body: (
      <p>
        Product availability can vary by season, supply and location. Listing a product category on this website does
        not guarantee that a particular product is in stock. Services such as delivery may depend on location and
        order details.
      </p>
    ),
  },
  {
    id: "agricultural-advice",
    title: "Agricultural Advice Disclaimer",
    body: (
      <>
        <p>
          Any guidance shared through this website, by phone or on WhatsApp is general in nature. Crop results depend
          on many factors outside our control, including soil, weather, water, pests, crop variety and farming
          practices.
        </p>
        <p>
          Always read and follow the manufacturer&rsquo;s label and instructions for any fertilizer or crop
          protection product, including dosage and safety precautions. Where needed, consult a qualified agricultural
          officer or agronomist for advice specific to your farm.
        </p>
      </>
    ),
  },
  {
    id: "third-party-links",
    title: "Third-Party Links",
    body: (
      <p>
        This website may contain links to third-party websites and services, such as WhatsApp and Google Maps. We do
        not control these services and are not responsible for their content or practices.
      </p>
    ),
  },
  {
    id: "intellectual-property",
    title: "Intellectual Property",
    body: (
      <p>
        The content, design, text and graphics on this website belong to {name} or are used with permission, unless
        stated otherwise. Product names and brands mentioned may belong to their respective owners. Please do not
        copy or reuse website content without permission.
      </p>
    ),
  },
  {
    id: "liability",
    title: "Limitation of Liability",
    body: (
      <p>
        To the extent permitted by applicable law, {name} is not liable for any loss or damage arising from the use of
        this website or reliance on its general information. Nothing in these terms limits any rights you have under
        applicable consumer protection laws.
      </p>
    ),
  },
  {
    id: "changes",
    title: "Changes to These Terms",
    body: <p>We may update these terms from time to time. The latest version will always be available on this page.</p>,
  },
  {
    id: "contact",
    title: "Contact Details",
    body: (
      <p>
        <strong>{name}</strong>
        <br />
        {formattedAddress().join(", ")}
        <br />
        Phone: {company.phoneDisplay}
        <br />
        Email: {company.email}
      </p>
    ),
  },
];

export default function TermsPage() {
  return (
    <LegalPage
      eyebrow="Legal"
      title="Terms & Conditions"
      intro={
        <p>
          These terms apply to your use of the {name} website. By using this website, you agree to these terms. If
          you do not agree, please do not use the website.
        </p>
      }
      sections={sections}
    />
  );
}
