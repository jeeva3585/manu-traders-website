import { ArrowLeft } from "lucide-react";
import { ButtonLink } from "@/components/ui/Button";

export default function NotFound() {
  return (
    <section className="on-dark flex min-h-[80svh] items-center bg-forest-950 pt-24 text-white">
      <div className="container-site">
        <p className="type-eyebrow text-leaf-200">404 · Page not found</p>
        <h1 className="type-display mt-5 max-w-2xl">This field is still being prepared.</h1>
        <p className="type-lead mt-5 max-w-lg text-white/65">The page you&rsquo;re looking for doesn&rsquo;t exist or has moved.</p>
        <div className="mt-9">
          <ButtonLink href="/" iconLeft={<ArrowLeft className="size-5" />}>
            Back to Home
          </ButtonLink>
        </div>
      </div>
    </section>
  );
}
