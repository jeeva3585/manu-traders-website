import type { Metadata } from "next";
import { LegalPage, type LegalSection } from "@/components/layout/LegalPage";
import { company } from "@/data/company";
import { formattedAddress } from "@/lib/company";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: `How ${company.companyName} collects, uses and protects information shared through this website.`,
  alternates: { canonical: "/privacy-policy" },
};

const name = company.companyName;

/** Edit or remove sections here. Keep wording factual — only describe practices you actually follow. */
const sections: LegalSection[] = [
  {
    id: "information-we-collect",
    title: "Information We Collect",
    body: (
      <>
        <p>We collect only the information you choose to share with us, such as:</p>
        <ul>
          <li>Your name, mobile number and location (village, town or district).</li>
          <li>Details about your crop, product requirements or questions included in your message.</li>
          <li>Any information you share when you call, message or email us.</li>
        </ul>
      </>
    ),
  },
  {
    id: "enquiry-forms",
    title: "Enquiry Forms",
    body: (
      <p>
        When you submit the enquiry form on this website, the details you enter are used to respond to your enquiry,
        for example to share product information, availability or pricing. We do not use enquiry details for
        unrelated purposes.
      </p>
    ),
  },
  {
    id: "contact-information",
    title: "How We Use Contact Information",
    body: (
      <ul>
        <li>To reply to your enquiries and provide the information or service you requested.</li>
        <li>To coordinate orders, delivery or other services you have asked for.</li>
        <li>To keep basic records of customer communication for business purposes.</li>
      </ul>
    ),
  },
  {
    id: "whatsapp",
    title: "WhatsApp Communication",
    body: (
      <>
        <p>
          If you contact us on WhatsApp, your messages are exchanged through WhatsApp, a service operated by a third
          party (Meta). Your use of WhatsApp is also subject to WhatsApp&rsquo;s own terms and privacy policy.
        </p>
        <p>
          We use WhatsApp to respond to your messages and share information you request. You can ask us to stop
          messaging you at any time by replying with your request.
        </p>
      </>
    ),
  },
  {
    id: "analytics",
    title: "Analytics",
    body: (
      <p>
        [Placeholder] This website does not currently use analytics tools. If analytics are added in future (for
        example to understand how many people visit the site), this section will be updated to describe the tool
        used and the information it collects.
      </p>
    ),
  },
  {
    id: "cookies",
    title: "Cookies",
    body: (
      <p>
        [Placeholder] This website does not currently set cookies for tracking or advertising. If cookies are used in
        future, this section will be updated to explain what they are used for and how you can control them.
      </p>
    ),
  },
  {
    id: "external-services",
    title: "External Services",
    body: (
      <p>
        This website may link to or embed services operated by others, such as WhatsApp and Google Maps. When you use
        those services, their own privacy policies apply. We are not responsible for the practices of third-party
        services.
      </p>
    ),
  },
  {
    id: "data-security",
    title: "Data Security",
    body: (
      <p>
        We take reasonable steps to protect the information you share with us. However, no method of transmission
        over the internet or electronic storage is completely secure, and we cannot guarantee absolute security.
      </p>
    ),
  },
  {
    id: "your-rights",
    title: "Your Rights",
    body: (
      <>
        <p>You may contact us to:</p>
        <ul>
          <li>Ask what personal information we hold about you.</li>
          <li>Request correction of inaccurate information.</li>
          <li>Request deletion of your information, where we are not required to keep it.</li>
          <li>Ask us to stop contacting you.</li>
        </ul>
      </>
    ),
  },
  {
    id: "changes",
    title: "Changes to This Policy",
    body: <p>We may update this policy from time to time. The latest version will always be available on this page.</p>,
  },
  {
    id: "contact",
    title: "Contact Information",
    body: (
      <>
        <p>For any questions about this Privacy Policy, please contact:</p>
        <p>
          <strong>{name}</strong>
          <br />
          {formattedAddress().join(", ")}
          <br />
          Phone: {company.phoneDisplay}
          <br />
          Email: {company.email}
        </p>
      </>
    ),
  },
];

export default function PrivacyPolicyPage() {
  return (
    <LegalPage
      eyebrow="Legal"
      title="Privacy Policy"
      intro={
        <p>
          This Privacy Policy explains how {name} (&ldquo;we&rdquo;, &ldquo;us&rdquo;) handles information shared
          with us through this website and related communication channels such as phone and WhatsApp.
        </p>
      }
      sections={sections}
    />
  );
}
