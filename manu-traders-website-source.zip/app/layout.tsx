import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import { CustomCursor } from "@/components/animations/CustomCursor";
import { Footer } from "@/components/layout/Footer";
import { Navbar } from "@/components/layout/Navbar";
import { Providers } from "@/components/layout/Providers";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { JsonLd } from "@/components/ui/JsonLd";
import { company } from "@/data/company";
import { localBusinessSchema, organizationSchema, websiteSchema } from "@/lib/schema";
import "./globals.css";

const outfit = localFont({
  src: "./fonts/Outfit-Variable.woff2",
  variable: "--font-outfit",
  weight: "100 900",
  display: "swap",
});

const inter = localFont({
  src: [
    { path: "./fonts/Inter-Variable.woff2", style: "normal", weight: "100 900" },
    { path: "./fonts/Inter-Variable-Italic.woff2", style: "italic", weight: "100 900" },
  ],
  variable: "--font-inter",
  display: "swap",
});

const title = "MANU Traders | Agricultural Fertilizers & Farm Inputs";
const description =
  "MANU Traders supplies trusted fertilizers, crop nutrition products and agricultural inputs to farmers.";

export const metadata: Metadata = {
  metadataBase: new URL(company.siteUrl),
  title: { default: title, template: "%s | MANU Traders" },
  description,
  applicationName: company.companyName,
  keywords: [
    "MANU Traders",
    "fertilizer shop Tamil Nadu",
    "agricultural inputs",
    "crop nutrition",
    "micronutrients",
    "seeds",
    "crop protection",
    "coconut root feeding",
  ],
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    locale: "en_IN",
    url: "/",
    siteName: company.companyName,
    title,
    description,
    images: [{ url: "/images/og-image.jpg", width: 1200, height: 630, alt: "MANU Traders — Growing Together With Farmers" }],
  },
  twitter: {
    card: "summary_large_image",
    title,
    description,
    images: ["/images/og-image.jpg"],
  },
  robots: { index: true, follow: true },
  formatDetection: { telephone: true, email: true, address: false },
};

export const viewport: Viewport = {
  themeColor: "#00170b",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  const local = localBusinessSchema();
  const schemas = [organizationSchema(), websiteSchema(), ...(local ? [local] : [])];

  return (
    <html lang="en-IN" className={`${outfit.variable} ${inter.variable}`}>
      <body className="min-h-dvh bg-cream-100 text-ink antialiased">
        <a
          href="#main"
          className="fixed left-4 top-4 z-[200] -translate-y-24 rounded-full bg-forest-950 px-5 py-3 font-semibold text-white transition-transform focus:translate-y-0"
        >
          Skip to content
        </a>
        <JsonLd data={schemas} />
        <Providers>
          <Navbar />
          <main id="main">{children}</main>
          <Footer />
          <WhatsAppButton />
          <CustomCursor />
        </Providers>
      </body>
    </html>
  );
}
