import { AboutSection } from "@/components/sections/AboutSection";
import { CinematicSection } from "@/components/sections/CinematicSection";
import { CoconutSection } from "@/components/sections/CoconutSection";
import { ContactCTA } from "@/components/sections/ContactCTA";
import { ContactSection } from "@/components/sections/ContactSection";
import { FarmJourney } from "@/components/sections/FarmJourney";
import { GrowthStory } from "@/components/sections/GrowthStory";
import { HeroSection } from "@/components/sections/HeroSection";
import { ParallaxBrandSection } from "@/components/sections/ParallaxBrandSection";
import { ProductsSection } from "@/components/sections/ProductsSection";
import { ServicesSection } from "@/components/sections/ServicesSection";
import { StatsSection } from "@/components/sections/StatsSection";
import { TestimonialsSection } from "@/components/sections/TestimonialsSection";
import { WhyChooseUs } from "@/components/sections/WhyChooseUs";

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <AboutSection />
      <ProductsSection />
      <CoconutSection />
      <CinematicSection />
      <WhyChooseUs />
      <GrowthStory />
      <FarmJourney />
      <ServicesSection />
      <StatsSection />
      <TestimonialsSection />
      <ParallaxBrandSection />
      <ContactCTA />
      <ContactSection />
    </>
  );
}
