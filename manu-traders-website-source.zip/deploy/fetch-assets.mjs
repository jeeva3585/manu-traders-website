/**
 * Regenerates binary assets (placeholder photos, fonts, icons) at build time,
 * so the deployable source stays text-only.
 *
 * - Photos: downloaded from the Stitch project's image URLs and cropped/converted to WebP.
 *   Set ASSET_SOURCE_DIR to a folder of local originals to skip downloading.
 * - Fonts: copied from @fontsource-variable packages.
 * - Icons: rendered from app/icon.svg.
 *
 * Replace the Stitch placeholders by committing real photos to public/images (same filenames)
 * and removing them from this script.
 */
import { copyFile, mkdir, readFile, access } from "node:fs/promises";
import path from "node:path";
import sharp from "sharp";

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const out = path.join(root, "public/images");
const lh3 = "https://lh3.googleusercontent.com/aida/";

const SOURCES = {
  "aerial-paddy": "AEtjO1VSxINltUyfwx0y-NnTxnloeSjdWprBLRQWtxkc_0aXY1QoRAu53Us1tLF9OfVN4VmwY7AJZauHX1-nopKXdDPn_EW8J9nNCNKdfcOq0xf6fskGhrw0NJSF43qXEHxijWQKsky4Xcw6tCWDrYD0KBT_96IRKxrCeqkeaE-vJK305Tsx6axQFNN6tUbHk0EGZDHRhrMqbgBtOCtVfndA3AsU75dEN6ojjnWrvrrwwgSie5XqPu47HFIAAw=s0",
  "dew-leaves": "AEtjO1XeqPBLSikdMw6R22ZTynQ-q-5SIh6QiiDYyoqReWzAM7DUGN-iEDMVKLRxDSlaAAbSQiLy8-mD3jYu5xcu15RGwCq6-D7SGPwP70gF0IgRfz4S0gkm7Fxk9v7Q93TNIZsucxQqMkxMhlxR_gjhZC8RspLvGkW049N66FSQt5EDQI2q6dzw07u9zBPk93E6VY1fA8DHtEMGidQnN8EiYmzS7jpsTlvTbxAk7ZsO_VIxwoyBEMPxe4yGkmM=s0",
  "golden-fields": "AEtjO1X43urBBG0y3MPVY5BJbJET0LLVDOT4KjSCJs6fT24LrXrFhxB14DAHSrvYSyQfKt7rJX_My8ecyevinTawoSni5x07NrNRWj7WFDJgMys-_r3U-cljMQuwySIuRpFcjufPQENX4-u8i94SmZCfcZUI6UW4eif42q9KD3t5NM4Ug1e4gnC7HEwQUAFSM9z1TbrHE12gvS6aBY2x4l8sJZww8o_y5a2iGoqI3i02LwbpEiaSKnfzFRIUzdk=s0",
  "soil-hands": "AEtjO1U_V-oFn6EzvunU3joQF4MyxO36FksqgYzDnVQWFePT4pgHJA6KSLzwN6JGUkzIhehU0fJHObebAJQ4COMrDTYLtxNORG71pVvcdU6uFPFaNsTg8yQXQtKby6uFDZrBSW8LVrctWK8XpEruBvJJxdP1Ei206CuSrf9fDtJCBnhOU8n9_nlkn7uA7ly7pUWdz-TQtukcWUUMwAso2I3vNtXRH5bIN8pFVMUXc56FYxYBExJH0IbuSKBZEQ=s0",
  agronomist: "AEtjO1XRXoP5lHDDDbfQLslgA1Gs5ul8-mH-Ilpyt6VCbvC5lO11DxLXfwvH-o7yw29ZllPTcrZyDXbsgfQar4l6GnLkSdOZMdDNfJ5HqY-G2M1PA2sxkDMljUfXB0fGj489KDgqBz3pRu4W8gxSu0gK-HgChvqx_dzCKEyEPNDpS_jQSNl_dX4TX16sv1an50V3ftppEQ5pyg1s9kN8a0JrHXeSAI7xxeO1TT6fct0F6gyf8hKedTz2HhGhJzM=s0",
  "coconut-grove": "AEtjO1WIWZwnXJhr7sVJIW2Co33W-brMjE2qGU8QIF9PRmzXUTIJc8KN4QfO73Iu91UW3wxWb9-myruEBW4PprP4MBIQgmJviaqAR-L16TUdR_xHO4qXapueG4pwf8aYvvA75qD09g-QZy8nvVkDW_N_cC_cKfdaZJgU1b6LhHzSkahiHhhmEJAo9BYsIPyzwvSu0POKfp01_Xmldkx2XSlBiR0zw2HYM3FnkDeg8-APRZ3OssmgjtkWpG-h028=s0",
  "coconut-root": "AEtjO1VckREBOVePb7-fN8iS4wdaBO0roemH7oGTUWouHYSypCK_aiyuw2yVBfnslgQMyXDNGx_yzF8wquDsMbm8CYNiIfe8OcIJtTM4V9lGJD3lSnxaq7uFwAnY1KqVZ0kn5Xqp78uap0xQ8eY9IJ_M7yTNeJe457ZMCnj3C1pJeOr1JC_M42yACJHPEKJh8Tt_jPEZf0LQ23uNYbFEN8cG4S7N-VQ7jHMiUo1MTbEGZ0n1PyIkficZs6lxjw=s0",
};

/** [output file, source, crop box as fractions (x0,y0,x1,y1) or null, resize] */
const OUTPUTS = [
  ["hero-farm.webp", "aerial-paddy"],
  ["about-crop-growth.webp", "dew-leaves"],
  ["cinematic-harvest.webp", "golden-fields"],
  ["soil-preparation.webp", "soil-hands"],
  ["farmer-field-guidance.webp", "agronomist"],
  ["coconut-grove.webp", "coconut-grove"],
  ["coconut-root-feeding.webp", "coconut-root"],
  ["communities-grow.webp", "coconut-grove", [0, 0, 1, 0.85]],
  ["product-fertilizers.webp", "soil-hands", [0.2, 0.35, 0.8, 0.95], [800, 600]],
  ["product-micronutrients.webp", "dew-leaves", [0.25, 0.1, 0.9, 0.75], [800, 600]],
  ["product-seeds.webp", "soil-hands", [0.3, 0.05, 0.85, 0.6], [800, 600]],
  ["product-crop-nutrition.webp", "golden-fields", [0, 0.3, 0.6, 1], [800, 600]],
  ["product-crop-protection.webp", "agronomist", [0.3, 0.1, 0.85, 0.9], [800, 600]],
  ["product-agricultural-inputs.webp", "coconut-root", [0.25, 0, 1, 0.75], [800, 600]],
];

async function exists(p) {
  try {
    await access(p);
    return true;
  } catch {
    return false;
  }
}

async function loadSource(name) {
  const local = process.env.ASSET_SOURCE_DIR && path.join(process.env.ASSET_SOURCE_DIR, `${name}.jpg`);
  if (local && (await exists(local))) return readFile(local);
  const res = await fetch(lh3 + SOURCES[name]);
  if (!res.ok) throw new Error(`Download failed for ${name}: HTTP ${res.status}`);
  return Buffer.from(await res.arrayBuffer());
}

async function main() {
  await mkdir(out, { recursive: true });

  const cache = new Map();
  for (const [file, src, box, size] of OUTPUTS) {
    const target = path.join(out, file);
    if (await exists(target)) continue; // keep real photos if committed
    if (!cache.has(src)) cache.set(src, await loadSource(src));
    let img = sharp(cache.get(src));
    if (box) {
      const { width, height } = await img.metadata();
      img = img.extract({
        left: Math.round(box[0] * width),
        top: Math.round(box[1] * height),
        width: Math.round((box[2] - box[0]) * width),
        height: Math.round((box[3] - box[1]) * height),
      });
    }
    if (size) img = img.resize(size[0], size[1]);
    await img.webp({ quality: 82, effort: 6 }).toFile(target);
    console.log("image", file);
  }

  // Open Graph image: field photo + deep green wash + emblem
  const og = path.join(out, "og-image.jpg");
  if (!(await exists(og))) {
    if (!cache.has("aerial-paddy")) cache.set("aerial-paddy", await loadSource("aerial-paddy"));
    const icon = await readFile(path.join(root, "app/icon.svg"));
    const wash = Buffer.from(
      `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630"><defs><linearGradient id="g" x1="0" x2="1"><stop offset="0" stop-color="#00170b" stop-opacity="0.85"/><stop offset="1" stop-color="#00170b" stop-opacity="0.35"/></linearGradient></defs><rect width="1200" height="630" fill="url(#g)"/></svg>`,
    );
    await sharp(cache.get("aerial-paddy"))
      .resize(1200, 630, { fit: "cover" })
      .composite([{ input: wash }, { input: await sharp(icon).resize(180, 180).png().toBuffer(), left: 80, top: 225 }])
      .jpeg({ quality: 82 })
      .toFile(og);
    console.log("image og-image.jpg");
  }

  // Fonts (self-hosted)
  const fonts = path.join(root, "app/fonts");
  await mkdir(fonts, { recursive: true });
  const fontCopies = [
    ["@fontsource-variable/outfit/files/outfit-latin-wght-normal.woff2", "Outfit-Variable.woff2"],
    ["@fontsource-variable/inter/files/inter-latin-wght-normal.woff2", "Inter-Variable.woff2"],
    ["@fontsource-variable/inter/files/inter-latin-wght-italic.woff2", "Inter-Variable-Italic.woff2"],
  ];
  for (const [from, to] of fontCopies) {
    const target = path.join(fonts, to);
    if (!(await exists(target))) await copyFile(path.join(root, "node_modules", from), target);
  }

  // Apple touch icon
  for (const p of ["app/apple-icon.png", "public/apple-icon.png"]) {
    const target = path.join(root, p);
    if (!(await exists(target))) {
      await sharp(await readFile(path.join(root, "app/icon.svg")), { density: 400 }).resize(180, 180).png().toFile(target);
    }
  }
  console.log("assets ready");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
