import type { NextConfig } from "next";

/**
 * STATIC_EXPORT=1 builds a fully static site into /out (served by nginx on the VPS).
 * Without it, the app runs as a normal Next.js server with image optimisation.
 */
const isStaticExport = process.env.STATIC_EXPORT === "1";

const nextConfig: NextConfig = {
  ...(isStaticExport ? { output: "export" as const, trailingSlash: true } : {}),
  images: {
    // Static hosting has no image optimiser; images are already pre-optimised WebP.
    unoptimized: isStaticExport,
    formats: ["image/avif", "image/webp"],
    qualities: [75, 85],
  },
  poweredByHeader: false,
};

export default nextConfig;
