import { company } from "@/data/company";

/** True when a config value is still a placeholder (empty, bracketed or contains X-masking). */
export function isPlaceholder(value: string | undefined | null): boolean {
  if (!value) return true;
  const v = value.trim();
  return v === "" || /\[.*\]/.test(v) || /X{4,}/i.test(v.replace(/\s/g, ""));
}

export function whatsappLink(message: string = company.whatsappMessage): string {
  const base = `https://wa.me/${company.whatsapp}`;
  return message ? `${base}?text=${encodeURIComponent(message)}` : base;
}

export function telLink(): string {
  return `tel:${company.phone}`;
}

export function mailLink(): string {
  return `mailto:${company.email}`;
}

export function formattedAddress(): string[] {
  const a = company.address;
  return [a.line1, a.line2, `${a.city}, ${a.district}`, `${a.state} ${a.postalCode}`];
}

export function hasRealAddress(): boolean {
  const a = company.address;
  return ![a.line1, a.city, a.postalCode].some(isPlaceholder);
}
