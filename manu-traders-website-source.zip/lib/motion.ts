import type { Transition, Variants } from "framer-motion";

/** Shared easing curves — keep UI motion consistent across the site. */
export const ease = {
  out: [0.22, 1, 0.36, 1] as const,
  inOut: [0.65, 0, 0.35, 1] as const,
  soft: [0.25, 0.1, 0.25, 1] as const,
};

/** Standard durations (seconds). UI: 0.3–0.7s, cinematic: slower. */
export const duration = {
  fast: 0.3,
  base: 0.55,
  slow: 0.8,
  cinematic: 1.4,
};

export const baseTransition: Transition = { duration: duration.base, ease: ease.out };

export const fadeUp: Variants = {
  hidden: { opacity: 0, y: 28 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: ease.out } },
};

export const fadeIn: Variants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { duration: 0.7, ease: ease.out } },
};

export const staggerContainer = (stagger = 0.1, delayChildren = 0): Variants => ({
  hidden: {},
  visible: { transition: { staggerChildren: stagger, delayChildren } },
});

/** Shared viewport config: animate once when ~20% visible. */
export const viewportOnce = { once: true, amount: 0.2 } as const;
