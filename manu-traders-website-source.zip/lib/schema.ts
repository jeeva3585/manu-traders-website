import { company } from "@/data/company";
import { hasRealAddress, isPlaceholder } from "@/lib/company";

type JsonLd = Record<string, unknown>;

const siteUrl = company.siteUrl.replace(/\/$/, "");

/** Organization + WebSite schema — only uses values that are already known. */
export function organizationSchema(): JsonLd {
  const org: JsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "@id": `${siteUrl}/#organization`,
    name: company.companyName,
    url: siteUrl,
    logo: `${siteUrl}/icon.svg`,
    slogan: company.tagline,
    description: company.description,
  };
  if (!isPlaceholder(company.phone)) org.telephone = company.phone;
  if (!isPlaceholder(company.email)) org.email = company.email;
  const sameAs = company.socialLinks.map((s) => s.href).filter(Boolean);
  if (sameAs.length) org.sameAs = sameAs;
  return org;
}

export function websiteSchema(): JsonLd {
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "@id": `${siteUrl}/#website`,
    url: siteUrl,
    name: company.companyName,
    publisher: { "@id": `${siteUrl}/#organization` },
    inLanguage: "en-IN",
  };
}

/**
 * LocalBusiness schema. Returns null until a real address is configured in
 * `data/company.ts`, so no unknown business data is ever published.
 */
export function localBusinessSchema(): JsonLd | null {
  if (!hasRealAddress()) return null;
  const a = company.address;
  const schema: JsonLd = {
    "@context": "https://schema.org",
    "@type": "Store",
    "@id": `${siteUrl}/#localbusiness`,
    name: company.companyName,
    url: siteUrl,
    image: `${siteUrl}/images/og-image.jpg`,
    parentOrganization: { "@id": `${siteUrl}/#organization` },
    address: {
      "@type": "PostalAddress",
      streetAddress: [a.line1, a.line2].filter((v) => !isPlaceholder(v)).join(", "),
      addressLocality: a.city,
      addressRegion: a.state,
      postalCode: a.postalCode,
      addressCountry: a.country,
    },
  };
  if (!isPlaceholder(company.phone)) schema.telephone = company.phone;
  if (company.mapsURL) schema.hasMap = company.mapsURL;
  const hours = company.businessHours.filter((h) => h.schema).map((h) => ({ "@type": "OpeningHoursSpecification", ...h.schema }));
  if (hours.length) schema.openingHoursSpecification = hours;
  if (company.serviceArea.length) {
    schema.areaServed = company.serviceArea.map((name) => ({ "@type": "AdministrativeArea", name }));
  }
  return schema;
}
