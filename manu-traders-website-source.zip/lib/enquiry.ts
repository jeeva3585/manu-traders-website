/**
 * Enquiry form model, validation and submission.
 *
 * No backend is connected yet. To connect one later, set
 * NEXT_PUBLIC_ENQUIRY_ENDPOINT (e.g. an n8n / Formspree / API route URL that accepts JSON POST),
 * or replace the body of `submitEnquiry` with your own integration.
 */

export type EnquiryData = {
  name: string;
  mobile: string;
  location: string;
  crop: string;
  message: string;
};

export type EnquiryErrors = Partial<Record<keyof EnquiryData, string>>;

export const emptyEnquiry: EnquiryData = { name: "", mobile: "", location: "", crop: "", message: "" };

export const cropOptions = [
  "Paddy",
  "Coconut",
  "Banana",
  "Sugarcane",
  "Vegetables",
  "Pulses",
  "Cotton",
  "Turmeric",
  "Other",
];

/** Normalises an Indian mobile number to 10 digits (strips +91 / 0 prefixes and spaces). */
export function normaliseMobile(value: string): string {
  const digits = value.replace(/\D/g, "");
  if (digits.length === 12 && digits.startsWith("91")) return digits.slice(2);
  if (digits.length === 11 && digits.startsWith("0")) return digits.slice(1);
  return digits;
}

export function validateEnquiry(data: EnquiryData): EnquiryErrors {
  const errors: EnquiryErrors = {};
  const name = data.name.trim();
  if (!name) errors.name = "Please enter your name.";
  else if (name.length < 2) errors.name = "Name looks too short.";

  const mobile = normaliseMobile(data.mobile);
  if (!data.mobile.trim()) errors.mobile = "Please enter your mobile number.";
  else if (!/^[6-9]\d{9}$/.test(mobile)) errors.mobile = "Enter a valid 10-digit Indian mobile number.";

  if (!data.location.trim()) errors.location = "Please enter your village, town or district.";

  const message = data.message.trim();
  if (!message) errors.message = "Please tell us what you need.";
  else if (message.length < 10) errors.message = "Please add a little more detail (at least 10 characters).";
  else if (message.length > 1000) errors.message = "Please keep your message under 1000 characters.";

  return errors;
}

/** Builds a readable WhatsApp message from the enquiry (used as the fallback channel). */
export function enquiryToMessage(data: EnquiryData): string {
  return [
    "Hello MANU Traders, I have an enquiry:",
    `Name: ${data.name.trim()}`,
    `Mobile: ${normaliseMobile(data.mobile)}`,
    `Location: ${data.location.trim()}`,
    data.crop ? `Crop: ${data.crop}` : null,
    `Message: ${data.message.trim()}`,
  ]
    .filter(Boolean)
    .join("\n");
}

export type SubmitResult = { status: "sent" } | { status: "not-configured" } | { status: "error"; message: string };

export async function submitEnquiry(data: EnquiryData): Promise<SubmitResult> {
  const endpoint = process.env.NEXT_PUBLIC_ENQUIRY_ENDPOINT;
  if (!endpoint) return { status: "not-configured" };

  try {
    const res = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...data, mobile: normaliseMobile(data.mobile), source: "website" }),
    });
    if (!res.ok) return { status: "error", message: "We couldn't send your enquiry. Please try again or contact us on WhatsApp." };
    return { status: "sent" };
  } catch {
    return { status: "error", message: "Network error. Please check your connection or contact us on WhatsApp." };
  }
}
