import { Boxes, ClipboardList, Truck, Tractor, Users, type LucideIcon } from "lucide-react";

export type Service = {
  icon: LucideIcon;
  title: string;
  text: string;
  tag: string;
  /** Set to false to hide a service that is not currently offered. */
  enabled: boolean;
};

/**
 * Services offered by MANU Traders.
 * If any service is confirmed as unavailable, set `enabled: false` (or delete the entry).
 */
export const services: Service[] = [
  {
    icon: Boxes,
    title: "Agricultural Input Supply",
    text: "Fertilizers, seeds, crop nutrition and protection products available when the season needs them.",
    tag: "Input Supply",
    enabled: true,
  },
  {
    icon: ClipboardList,
    title: "Farm Product Guidance",
    text: "Help choosing suitable products and quantities for your crop, soil and growth stage.",
    tag: "Product Advice",
    enabled: true,
  },
  {
    icon: Truck,
    title: "Farm Delivery",
    text: "Delivery of farm inputs to your village or field, subject to location and order size.",
    tag: "Doorstep Delivery",
    enabled: true,
  },
  {
    icon: Tractor,
    title: "Farm Work Support",
    text: "Support with arranging farm work related to input application and field operations.",
    tag: "Field Support",
    enabled: true,
  },
  {
    icon: Users,
    title: "Farmer Assistance",
    text: "Friendly, practical help for farmers with questions about products and their use.",
    tag: "Farmer Help Desk",
    enabled: true,
  },
];

export const featuredService = {
  eyebrow: "Field Guidance & Farmer Support",
  title: "Practical Advice From People Who Understand Farming",
  text: "Tell us your crop, its stage and the problem you are seeing. We help you choose suitable inputs and explain how to use them.",
  cta: "Talk to MANU Traders",
  image: "/images/farmer-field-guidance.webp",
  imageAlt: "Advisor and farmer discussing a healthy paddy crop in the field",
  chip: "Guidance for Every Season",
};
