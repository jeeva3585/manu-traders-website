import { BadgeCheck, HeartHandshake, PackageCheck, Sprout, type LucideIcon } from "lucide-react";

export type Benefit = { icon: LucideIcon; title: string; text: string; tag: string };

export const benefits: Benefit[] = [
  {
    icon: BadgeCheck,
    title: "Trusted Products",
    text: "Reliable agricultural products from trusted sources.",
    tag: "Genuine Inputs",
  },
  {
    icon: HeartHandshake,
    title: "Farmer\u2011Focused Service",
    text: "Solutions designed around real farming needs.",
    tag: "Farmer First",
  },
  {
    icon: PackageCheck,
    title: "Reliable Supply",
    text: "Consistent access to essential farm inputs.",
    tag: "Season Ready",
  },
  {
    icon: Sprout,
    title: "Practical Support",
    text: "Helping farmers choose suitable products for their crops.",
    tag: "Right Product, Right Crop",
  },
];
