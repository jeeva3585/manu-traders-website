import { Droplet, Shield, Headset, type LucideIcon } from "lucide-react";

/**
 * Coconut care section (added in the Stitch design).
 * Set `enabled: false` to hide the whole section, or remove individual items.
 */
export const coconutCare = {
  enabled: true,
  eyebrow: "Coconut & Plantation Care",
  title: "Specialised Coconut Care & Root Feeding",
  description:
    "Root feeding tonics, nutrition and plant protection inputs for coconut groves — with guidance on what to use and when.",
  cta: "Ask About Coconut Care",
  gallery: [
    {
      image: "/images/coconut-grove.webp",
      alt: "Coconut grove in Tamil Nadu with sunlight through the palm fronds",
      chip: "Coconut Groves",
      cardTitle: "Healthier Palms, Steadier Yields",
      cardText: "Nutrition and care inputs selected for coconut plantations.",
    },
    {
      image: "/images/coconut-root-feeding.webp",
      alt: "Root feeding pouch attached to the root zone of a coconut palm",
      chip: "Root Feeding",
      cardTitle: "Root Feeding Method",
      cardText: "Nutrients delivered directly through active roots of the palm.",
    },
  ],
  items: [
    {
      icon: Droplet,
      title: "Root Feeding Tonics",
      text: "Nutrient tonics applied through active roots to support nut setting and help reduce button shedding.",
      tag: "Root Nutrition",
    },
    {
      icon: Shield,
      title: "Pest & Disease Protection",
      text: "Protection inputs for common coconut problems such as rhinoceros beetle and red palm weevil.",
      tag: "Crown & Trunk Care",
    },
    {
      icon: Headset,
      title: "Application Guidance",
      text: "Help choosing the right product, dosage and timing for your grove's age and season.",
      tag: "Practical Advice",
    },
  ] as { icon: LucideIcon; title: string; text: string; tag: string }[],
};
