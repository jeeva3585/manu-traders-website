import {
  Droplets,
  FlaskConical,
  Package,
  ShieldCheck,
  Sprout,
  Wheat,
  type LucideIcon,
} from "lucide-react";

export type ProductCategory = {
  slug: string;
  title: string;
  description: string;
  badge: string;
  tags: string[];
  image: string;
  imageAlt: string;
  icon: LucideIcon;
};

/**
 * Product categories shown on the homepage.
 * Images are placeholders — replace files in /public/images with real MANU Traders photography
 * (keep the same filenames, or update the paths here).
 */
export const productCategories: ProductCategory[] = [
  {
    slug: "fertilizers",
    title: "Fertilizers",
    description:
      "Straight and complex fertilizers for balanced basal and top dressing across field and plantation crops.",
    badge: "Essential Base",
    tags: ["NPK Complexes", "Water Soluble", "Straight Fertilizers"],
    image: "/images/product-fertilizers.webp",
    imageAlt: "Farmer's hands holding rich dark soil with young seedlings",
    icon: Wheat,
  },
  {
    slug: "micronutrients",
    title: "Micronutrients",
    description:
      "Zinc, boron, iron, magnesium and mixed micronutrients to correct deficiencies and support healthy growth.",
    badge: "Deficiency Care",
    tags: ["Zinc", "Boron", "Multi-Micronutrient"],
    image: "/images/product-micronutrients.webp",
    imageAlt: "Close-up of healthy green crop leaves with morning dew",
    icon: Droplets,
  },
  {
    slug: "seeds",
    title: "Seeds",
    description:
      "Quality seeds for paddy, pulses, vegetables and other crops suited to local growing seasons.",
    badge: "Strong Start",
    tags: ["Paddy", "Pulses", "Vegetables"],
    image: "/images/product-seeds.webp",
    imageAlt: "Young seedlings emerging from fertile soil held in hands",
    icon: Sprout,
  },
  {
    slug: "crop-nutrition",
    title: "Crop Nutrition",
    description:
      "Bio-stimulants, organic manures and growth promoters that support vigorous, even crop development.",
    badge: "Growth Support",
    tags: ["Bio-Stimulants", "Organic Manure", "Growth Promoters"],
    image: "/images/product-crop-nutrition.webp",
    imageAlt: "Lush green paddy fields in golden morning light",
    icon: FlaskConical,
  },
  {
    slug: "crop-protection",
    title: "Crop Protection",
    description:
      "Insecticides, fungicides, herbicides and bio-pesticides to help protect crops through the season.",
    badge: "Targeted Defense",
    tags: ["Insecticides", "Fungicides", "Bio-Pesticides"],
    image: "/images/product-crop-protection.webp",
    imageAlt: "Farmer and advisor inspecting a healthy paddy crop together",
    icon: ShieldCheck,
  },
  {
    slug: "agricultural-inputs",
    title: "Agricultural Inputs",
    description:
      "Soil conditioners, spray adjuvants, plantation care and other everyday farm essentials.",
    badge: "Field Essentials",
    tags: ["Soil Conditioners", "Adjuvants", "Plantation Care"],
    image: "/images/product-agricultural-inputs.webp",
    imageAlt: "Root feeding pouch tied to a coconut tree base",
    icon: Package,
  },
];
