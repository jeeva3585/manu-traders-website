/**
 * Company statistics.
 *
 * ⚠️  PLACEHOLDERS — do not publish invented figures.
 * When real numbers are confirmed, set `value` to a number (e.g. 1200) and
 * the count-up animation will run automatically. While `value` is null,
 * `display` is shown as-is without animation.
 */
export type Stat = {
  value: number | null;
  suffix?: string;
  display: string;
  label: string;
  sub: string;
};

export const stats: Stat[] = [
  { value: null, suffix: "+", display: "XX+", label: "Farmers Served", sub: "Across our region" },
  { value: null, suffix: "+", display: "XX+", label: "Agricultural Products", sub: "Across key categories" },
  { value: null, suffix: "", display: "XX", label: "Years of Trust", sub: "Serving farming families" },
  { value: null, display: "Reliable", label: "Farmer Support", sub: "Before and after purchase" },
];
