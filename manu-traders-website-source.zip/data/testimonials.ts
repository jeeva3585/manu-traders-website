/**
 * Farmer testimonials.
 *
 * ⚠️  PLACEHOLDERS — replace with real, approved feedback from farmers before launch.
 * Keep `isPlaceholder: true` until then; the site shows a small "Sample" marker
 * so that sample text is never presented as genuine feedback.
 */
export type Testimonial = {
  name: string;
  location: string;
  crop?: string;
  feedback: string;
  isPlaceholder: boolean;
};

export const testimonials: Testimonial[] = [
  {
    name: "Farmer Name",
    location: "Village, District",
    crop: "Paddy",
    feedback:
      "Placeholder — add a farmer's own words about product quality and the guidance they received from MANU Traders.",
    isPlaceholder: true,
  },
  {
    name: "Farmer Name",
    location: "Village, District",
    crop: "Coconut",
    feedback:
      "Placeholder — add feedback about timely availability of inputs during the sowing or peak season.",
    isPlaceholder: true,
  },
  {
    name: "Farmer Name",
    location: "Village, District",
    crop: "Vegetables",
    feedback:
      "Placeholder — add feedback about delivery, service or support after purchase.",
    isPlaceholder: true,
  },
  {
    name: "Farmer Name",
    location: "Village, District",
    crop: "Banana",
    feedback:
      "Placeholder — add feedback about how the recommended crop nutrition worked in the field.",
    isPlaceholder: true,
  },
];
