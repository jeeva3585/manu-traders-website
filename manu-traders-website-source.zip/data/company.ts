/**
 * Central business configuration for MANU Traders.
 *
 * ⚠️  Every value wrapped in square brackets or containing "X" is a PLACEHOLDER.
 *     Replace them with confirmed business details before going live.
 *     Helpers in `lib/company.ts` detect placeholders so that structured data
 *     (LocalBusiness schema) and map embeds are only emitted for real values.
 */

export type SocialLink = {
  label: string;
  href: string;
};

export type BusinessHours = {
  /** Human-readable label shown on the site, e.g. "Monday – Saturday" */
  days: string;
  /** e.g. "8:00 AM – 8:00 PM" */
  time: string;
  /**
   * Optional schema.org values (only used for LocalBusiness JSON-LD once real
   * hours are confirmed). Example: { dayOfWeek: ["Monday","Tuesday"], opens: "08:00", closes: "20:00" }
   */
  schema?: { dayOfWeek: string[]; opens: string; closes: string };
};

export const company = {
  companyName: "MANU Traders",
  legalName: "MANU Traders", // [Confirm registered legal name]
  shortName: "MANU",
  tagline: "Growing Together With Farmers",
  supportingLine: "Quality Agricultural Inputs • Reliable Service • Trusted Support",
  description:
    "MANU Traders supplies trusted fertilizers, crop nutrition products and agricultural inputs to farmers.",
  region: "Tamil Nadu, India",

  /** Public website URL — also set NEXT_PUBLIC_SITE_URL in your hosting environment. */
  siteUrl: process.env.NEXT_PUBLIC_SITE_URL ?? "https://www.example.com",

  /** Phone number in international format without spaces, used for tel: links. */
  phone: "+91XXXXXXXXXX",
  /** Phone number as it should be displayed to visitors. */
  phoneDisplay: "+91 XXXXX XXXXX",

  /** WhatsApp number: country code + number, digits only (no +, spaces or dashes). */
  whatsapp: "91XXXXXXXXXX",
  whatsappDisplay: "+91 XXXXX XXXXX",
  whatsappMessage:
    "Hello MANU Traders, I would like to know more about your agricultural products.",

  email: "[email@manutraders.example]",

  address: {
    line1: "[Shop / Door No., Street Name]",
    line2: "[Area / Village]",
    city: "[Town / City]",
    district: "[District]",
    state: "Tamil Nadu",
    postalCode: "[PIN Code]",
    country: "IN",
  },

  /** Link that opens the shop in Google Maps (Share → Copy link). */
  mapsURL: "",
  /** Google Maps "Embed a map" iframe src. Leave empty to show a placeholder panel. */
  mapsEmbedURL: "",

  businessHours: [
    { days: "[Monday – Saturday]", time: "[Opening time – Closing time]" },
    { days: "[Sunday]", time: "[Closed / Hours]" },
  ] as BusinessHours[],

  /** Add only real, active profiles. Empty list hides the social row. */
  socialLinks: [] as SocialLink[],

  /** Optional — areas served, used in LocalBusiness schema once confirmed. */
  serviceArea: [] as string[],

  /** Date shown on the Privacy Policy and Terms pages. */
  legalLastUpdated: "[DD Month YYYY]",
} as const;

export type Company = typeof company;
