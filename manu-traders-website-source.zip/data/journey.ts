import { Shovel, FlaskConical, ShieldCheck, Sprout, Wheat, type LucideIcon } from "lucide-react";

export type JourneyStage = {
  number: string;
  title: string;
  text: string;
  focus: string;
  icon: LucideIcon;
};

export const journeyStages: JourneyStage[] = [
  {
    number: "01",
    title: "Soil Preparation",
    text: "Basal fertilizers, organic manure and soil conditioners to build a healthy root bed.",
    focus: "Root Bed Health",
    icon: Shovel,
  },
  {
    number: "02",
    title: "Crop Nutrition",
    text: "Balanced NPK and micronutrients matched to each stage of vegetative growth.",
    focus: "Strong Vegetative Base",
    icon: FlaskConical,
  },
  {
    number: "03",
    title: "Crop Protection",
    text: "Timely protection from pests and diseases to keep the canopy healthy.",
    focus: "Healthy Canopy",
    icon: ShieldCheck,
  },
  {
    number: "04",
    title: "Healthy Growth",
    text: "Growth promoters and nutrition support through flowering and fruit set.",
    focus: "Flowering Stability",
    icon: Sprout,
  },
  {
    number: "05",
    title: "Better Harvest",
    text: "Nutrition for grain filling and fruit development, for a better quality harvest.",
    focus: "Harvest Quality",
    icon: Wheat,
  },
];

/** Stages for the scroll-driven crop growth motion graphic. */
export const growthStages = [
  { key: "seed", label: "Seed", text: "A quality seed is placed in well-prepared soil." },
  { key: "root", label: "Root", text: "Roots spread out to anchor the plant and draw nutrients." },
  { key: "sprout", label: "Sprout", text: "The first shoot breaks through the surface towards the light." },
  { key: "plant", label: "Plant", text: "Balanced nutrition builds a strong stem." },
  { key: "leaves", label: "Healthy Crop", text: "Leaves develop and the crop is protected through the season." },
  { key: "harvest", label: "Harvest", text: "Healthy grain heads ready for a rewarding harvest." },
] as const;
