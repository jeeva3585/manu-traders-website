export type NavItem = { label: string; href: string; id: string };

/** Primary navigation — `id` must match the section element id on the homepage. */
export const mainNav: NavItem[] = [
  { label: "Home", href: "/#home", id: "home" },
  { label: "About", href: "/#about", id: "about" },
  { label: "Products", href: "/#products", id: "products" },
  { label: "Services", href: "/#services", id: "services" },
  { label: "Why Us", href: "/#why-us", id: "why-us" },
  { label: "Contact", href: "/#contact", id: "contact" },
];

export const footerNav: NavItem[] = [
  { label: "Home", href: "/#home", id: "home" },
  { label: "About", href: "/#about", id: "about" },
  { label: "Products", href: "/#products", id: "products" },
  { label: "Services", href: "/#services", id: "services" },
  { label: "Contact", href: "/#contact", id: "contact" },
];

export const legalNav = [
  { label: "Privacy Policy", href: "/privacy-policy" },
  { label: "Terms & Conditions", href: "/terms" },
];
