import { ChevronRight, Clock, Mail, MapPin, MessageCircle, Phone } from "lucide-react";
import Link from "next/link";
import { Logo } from "@/components/ui/Logo";
import { company } from "@/data/company";
import { footerNav, legalNav } from "@/data/navigation";
import { formattedAddress, mailLink, telLink, whatsappLink } from "@/lib/company";
import { CurrentYear } from "@/components/layout/CurrentYear";

export function Footer() {
  return (
    <footer className="on-dark relative overflow-hidden bg-forest-950 text-white" aria-labelledby="footer-heading">
      <h2 id="footer-heading" className="sr-only">
        Footer
      </h2>
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-40 top-0 size-[36rem] rounded-full bg-leaf-600/15 blur-3xl"
      />

      <div className="container-site relative pb-28 pt-20 md:pb-10 lg:pt-24">
        <div className="grid gap-14 lg:grid-cols-12 lg:gap-10">
          <div className="lg:col-span-5">
            <Logo tone="light" />
            <p className="mt-7 font-display text-2xl font-medium italic text-leaf-200">
              &ldquo;{company.tagline}.&rdquo;
            </p>
            <p className="mt-4 max-w-md leading-relaxed text-white/60">
              Quality agricultural inputs, reliable service and trusted support for farmers across {company.region}.
            </p>
            {company.socialLinks.length > 0 ? (
              <ul className="mt-7 flex flex-wrap gap-3">
                {company.socialLinks.map((s) => (
                  <li key={s.href}>
                    <a
                      href={s.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="rounded-full px-4 py-2 text-sm text-white/80 ring-1 ring-white/15 transition hover:bg-white/10 hover:text-white"
                    >
                      {s.label}
                    </a>
                  </li>
                ))}
              </ul>
            ) : null}
          </div>

          <nav aria-label="Footer" className="grid grid-cols-2 gap-10 lg:col-span-3 lg:grid-cols-1">
            <div>
              <h3 className="font-display text-lg font-semibold">Quick Links</h3>
              <ul className="mt-5 space-y-3">
                {footerNav.map((item) => (
                  <li key={item.id}>
                    <Link
                      href={item.href}
                      className="group inline-flex items-center gap-1.5 text-white/65 transition-colors hover:text-leaf-200"
                    >
                      <ChevronRight aria-hidden="true" className="size-3.5 transition-transform group-hover:translate-x-0.5" />
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="font-display text-lg font-semibold">Legal</h3>
              <ul className="mt-5 space-y-3">
                {legalNav.map((item) => (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      className="group inline-flex items-center gap-1.5 text-white/65 transition-colors hover:text-leaf-200"
                    >
                      <ChevronRight aria-hidden="true" className="size-3.5 transition-transform group-hover:translate-x-0.5" />
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </nav>

          <div className="lg:col-span-4">
            <h3 className="font-display text-lg font-semibold">Contact</h3>
            <address className="mt-5 space-y-4 not-italic text-white/70">
              <p className="flex gap-3">
                <MapPin aria-hidden="true" className="mt-1 size-4 shrink-0 text-leaf-200" />
                <span>{formattedAddress().join(", ")}</span>
              </p>
              <p className="flex gap-3">
                <Phone aria-hidden="true" className="mt-1 size-4 shrink-0 text-leaf-200" />
                <a href={telLink()} className="hover:text-white">
                  {company.phoneDisplay}
                </a>
              </p>
              <p className="flex gap-3">
                <MessageCircle aria-hidden="true" className="mt-1 size-4 shrink-0 text-leaf-200" />
                <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="hover:text-white">
                  WhatsApp: {company.whatsappDisplay}
                </a>
              </p>
              <p className="flex gap-3">
                <Mail aria-hidden="true" className="mt-1 size-4 shrink-0 text-leaf-200" />
                <a href={mailLink()} className="break-all hover:text-white">
                  {company.email}
                </a>
              </p>
              <p className="flex gap-3">
                <Clock aria-hidden="true" className="mt-1 size-4 shrink-0 text-leaf-200" />
                <span>{company.businessHours.map((h) => `${h.days}: ${h.time}`).join(" · ")}</span>
              </p>
            </address>
          </div>
        </div>

        <div className="mt-16 flex flex-col gap-4 border-t border-white/10 pt-8 text-sm text-white/50 md:flex-row md:items-center md:justify-between">
          <p>
            © <CurrentYear /> {company.companyName}. All Rights Reserved.
          </p>
          <p>{company.supportingLine}</p>
        </div>
      </div>
    </footer>
  );
}
