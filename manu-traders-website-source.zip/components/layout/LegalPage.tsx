import { ArrowLeft } from "lucide-react";
import Link from "next/link";
import type { ReactNode } from "react";
import { SectionLabel } from "@/components/ui/SectionLabel";
import { company } from "@/data/company";

export type LegalSection = { id: string; title: string; body: ReactNode };

/** Shared layout for Privacy Policy and Terms pages: hero band, table of contents, prose. */
export function LegalPage({
  eyebrow,
  title,
  intro,
  sections,
}: {
  eyebrow: string;
  title: string;
  intro: ReactNode;
  sections: LegalSection[];
}) {
  return (
    <>
      <header className="on-dark relative overflow-hidden bg-forest-950 pb-16 pt-36 text-white lg:pb-20 lg:pt-44">
        <div aria-hidden="true" className="pointer-events-none absolute -right-32 -top-32 size-[32rem] rounded-full bg-leaf-600/25 blur-3xl" />
        <div className="container-site relative">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm font-semibold text-white/70 transition-colors hover:text-leaf-200"
          >
            <ArrowLeft aria-hidden="true" className="size-4" /> Back to home
          </Link>
          <div className="mt-8">
            <SectionLabel tone="glass">{eyebrow}</SectionLabel>
          </div>
          <h1 className="type-display mt-6 max-w-3xl">{title}</h1>
          <p className="mt-5 text-sm text-white/55">Last updated: {company.legalLastUpdated}</p>
        </div>
      </header>

      <div className="container-site grid gap-12 py-16 lg:grid-cols-12 lg:py-24">
        <nav aria-label="On this page" className="lg:col-span-4">
          <div className="rounded-[1.5rem] bg-cream-200 p-6 lg:sticky lg:top-28">
            <p className="type-eyebrow text-leaf-600">On this page</p>
            <ol className="mt-4 grid gap-2 text-sm">
              {sections.map((s, i) => (
                <li key={s.id}>
                  <a href={`#${s.id}`} className="flex gap-3 rounded-lg py-1 text-ink-muted transition-colors hover:text-forest-950">
                    <span className="w-5 shrink-0 font-semibold text-ink-soft">{i + 1}.</span>
                    {s.title}
                  </a>
                </li>
              ))}
            </ol>
          </div>
        </nav>

        <article className="legal-prose max-w-3xl lg:col-span-8">
          <div className="text-lg leading-relaxed text-ink-muted">{intro}</div>
          {sections.map((s, i) => (
            <section key={s.id} id={s.id} aria-labelledby={`${s.id}-h`}>
              <h2 id={`${s.id}-h`}>
                {i + 1}. {s.title}
              </h2>
              {s.body}
            </section>
          ))}
          <p className="mt-14 rounded-2xl bg-gold-100/60 p-5 text-sm">
            This page is a general template provided for convenience and is not legal advice. Please have it reviewed
            by a qualified professional before relying on it.
          </p>
        </article>
      </div>
    </>
  );
}
