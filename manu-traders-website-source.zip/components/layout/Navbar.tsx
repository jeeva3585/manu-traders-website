"use client";

import { AnimatePresence, motion } from "framer-motion";
import { MessageCircle } from "lucide-react";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { MobileMenu } from "@/components/layout/MobileMenu";
import { useLenis } from "@/components/animations/SmoothScroll";
import { ButtonLink } from "@/components/ui/Button";
import { Logo } from "@/components/ui/Logo";
import { mainNav } from "@/data/navigation";
import { useActiveSection } from "@/hooks/useActiveSection";
import { useScrolled } from "@/hooks/useScrolled";
import { whatsappLink } from "@/lib/company";
import { ease } from "@/lib/motion";
import { cn } from "@/lib/utils";

const sectionIds = mainNav.map((n) => n.id);

/**
 * Floating header.
 * - Over the hero: transparent with light text.
 * - After scrolling (or on inner pages): compact glass pill with border + shadow.
 */
export function Navbar() {
  const pathname = usePathname();
  const isHome = pathname === "/";
  const scrolled = useScrolled(32);
  const active = useActiveSection(isHome ? sectionIds : []);
  const [open, setOpen] = useState(false);
  const solid = (scrolled || !isHome) && !open;
  const lenis = useLenis();

  // Lock page scroll while the mobile menu is open.
  useEffect(() => {
    if (open) {
      lenis?.stop();
      document.documentElement.style.overflow = "hidden";
    } else {
      lenis?.start();
      document.documentElement.style.overflow = "";
    }
  }, [open, lenis]);

  return (
    <>
      <motion.header
        initial={{ y: -24, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: ease.out, delay: 0.1 }}
        className={cn("fixed inset-x-0 top-0 px-3 pt-3 md:px-6 md:pt-4", open ? "z-[70]" : "z-50")}
      >
        <div
          className={cn(
            "mx-auto flex max-w-[1360px] items-center justify-between rounded-full transition-[height,background-color,box-shadow,padding,border-color] duration-500 ease-out-expo",
            "border",
            solid
              ? "h-16 border-white/70 bg-cream-100/80 pl-4 pr-2 shadow-[0_10px_40px_-12px_rgba(15,45,30,0.18)] backdrop-blur-xl backdrop-saturate-150 md:pl-5"
              : "h-20 border-transparent bg-transparent pl-2 pr-0 md:pl-4",
          )}
        >
          <Logo tone={solid ? "dark" : "light"} showTagline={!solid} />

          <nav aria-label="Primary" className="hidden xl:block">
            <ul
              className={cn(
                "flex items-center gap-1 rounded-full p-1 transition-colors duration-500",
                solid ? "bg-cream-300/70" : "bg-white/8 ring-1 ring-inset ring-white/12 backdrop-blur-md",
              )}
            >
              {mainNav.map((item) => {
                const isActive = isHome && active === item.id;
                return (
                  <li key={item.id} className="relative">
                    {isActive ? (
                      <motion.span
                        layoutId="nav-pill"
                        className={cn("absolute inset-0 rounded-full", solid ? "bg-white shadow-sm" : "bg-white/15")}
                        transition={{ type: "spring", stiffness: 380, damping: 34 }}
                      />
                    ) : null}
                    <a
                      href={item.href}
                      aria-current={isActive ? "location" : undefined}
                      className={cn(
                        "relative block rounded-full px-4 py-2 text-sm font-medium transition-colors duration-300",
                        solid
                          ? isActive
                            ? "text-forest-950"
                            : "text-ink-muted hover:text-forest-950"
                          : isActive
                            ? "text-white"
                            : "text-white/75 hover:text-white",
                      )}
                    >
                      {item.label}
                    </a>
                  </li>
                );
              })}
            </ul>
          </nav>

          <div className="flex items-center gap-2">
            <span className="hidden sm:block">
              <ButtonLink
                href={whatsappLink()}
                variant="accent"
                size="sm"
                iconLeft={<MessageCircle className="size-4" />}
                aria-label="WhatsApp Us (opens WhatsApp)"
              >
                WhatsApp Us
              </ButtonLink>
            </span>
            <span className="hidden md:block">
              <ButtonLink href="/#contact" variant={solid ? "dark" : "light"} size="sm">
                Enquire Now
              </ButtonLink>
            </span>

            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              aria-expanded={open}
              aria-controls="mobile-menu"
              aria-label={open ? "Close menu" : "Open menu"}
              className={cn(
                "relative z-[61] grid size-12 place-items-center rounded-full transition-colors duration-300 xl:hidden",
                open
                  ? "bg-leaf-200 text-forest-950"
                  : solid
                    ? "bg-forest-950 text-white"
                    : "bg-white/10 text-white ring-1 ring-inset ring-white/20 backdrop-blur-md",
              )}
            >
              <span className="relative block h-3.5 w-5" aria-hidden="true">
                <motion.span
                  className="absolute left-0 top-0 h-[2px] w-5 rounded-full bg-current"
                  animate={open ? { top: "6px", rotate: 45 } : { top: "0px", rotate: 0 }}
                  transition={{ duration: 0.35, ease: ease.out }}
                />
                <motion.span
                  className="absolute bottom-0 right-0 h-[2px] rounded-full bg-current"
                  animate={open ? { bottom: "6px", rotate: -45, width: "20px" } : { bottom: "0px", rotate: 0, width: "13px" }}
                  transition={{ duration: 0.35, ease: ease.out }}
                />
              </span>
            </button>
          </div>
        </div>
      </motion.header>

      <AnimatePresence>{open ? <MobileMenu onClose={() => setOpen(false)} /> : null}</AnimatePresence>
    </>
  );
}
