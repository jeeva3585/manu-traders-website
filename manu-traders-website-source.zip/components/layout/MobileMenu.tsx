"use client";

import { motion } from "framer-motion";
import { ArrowUpRight, MessageCircle, Phone } from "lucide-react";
import { useEffect, useRef } from "react";
import { ButtonLink } from "@/components/ui/Button";
import { company } from "@/data/company";
import { mainNav } from "@/data/navigation";
import { telLink, whatsappLink } from "@/lib/company";
import { ease } from "@/lib/motion";

/** Full-screen animated menu for mobile & tablet. Traps focus and closes on Escape. */
export function MobileMenu({ onClose }: { onClose: () => void }) {
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const panel = panelRef.current;
    const previouslyFocused = document.activeElement as HTMLElement | null;
    panel?.querySelector<HTMLElement>("a")?.focus();

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key !== "Tab" || !panel) return;
      // Include the toggle button (outside the panel) in the focus loop.
      const toggle = document.querySelector<HTMLElement>('[aria-controls="mobile-menu"]');
      const focusables = [
        ...(toggle ? [toggle] : []),
        ...Array.from(panel.querySelectorAll<HTMLElement>("a, button")),
      ];
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("keydown", onKey);
      previouslyFocused?.focus?.();
    };
  }, [onClose]);

  return (
    <motion.div
      id="mobile-menu"
      ref={panelRef}
      role="dialog"
      aria-modal="true"
      aria-label="Site menu"
      className="on-dark fixed inset-0 z-[60] flex flex-col overflow-y-auto bg-forest-950 text-white xl:hidden"
      initial={{ clipPath: "circle(0% at calc(100% - 3rem) 2.75rem)" }}
      animate={{ clipPath: "circle(150% at calc(100% - 3rem) 2.75rem)" }}
      exit={{ clipPath: "circle(0% at calc(100% - 3rem) 2.75rem)" }}
      transition={{ duration: 0.65, ease: ease.inOut }}
    >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-24 -top-24 size-[28rem] rounded-full bg-leaf-600/25 blur-3xl"
      />
      <div aria-hidden="true" className="pointer-events-none absolute -bottom-32 -left-20 size-[22rem] rounded-full bg-gold-500/10 blur-3xl" />

      <nav aria-label="Mobile" className="container-site relative flex flex-1 flex-col justify-center pb-10 pt-28">
        <ul className="flex flex-col">
          {mainNav.map((item, i) => (
            <motion.li
              key={item.id}
              initial={{ opacity: 0, y: 28 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 12, transition: { duration: 0.2 } }}
              transition={{ duration: 0.6, ease: ease.out, delay: 0.18 + i * 0.06 }}
              className="border-b border-white/10"
            >
              <a
                href={item.href}
                onClick={onClose}
                className="group flex items-center justify-between py-4 font-display text-[2.1rem] font-semibold leading-none tracking-[-0.02em] text-white/90 transition-colors hover:text-leaf-200 sm:text-5xl"
              >
                <span className="flex items-baseline gap-4">
                  <span className="font-sans text-xs font-semibold tracking-[0.2em] text-leaf-200/70">
                    0{i + 1}
                  </span>
                  {item.label}
                </span>
                <ArrowUpRight
                  aria-hidden="true"
                  className="size-6 -translate-x-2 opacity-0 transition-all duration-300 group-hover:translate-x-0 group-hover:opacity-100"
                />
              </a>
            </motion.li>
          ))}
        </ul>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6, ease: ease.out, delay: 0.55 }}
          className="mt-10 flex flex-col gap-3 sm:flex-row"
        >
          <ButtonLink
            href={whatsappLink()}
            variant="accent"
            size="lg"
            iconLeft={<MessageCircle className="size-5" />}
            onClick={onClose}
          >
            WhatsApp Us
          </ButtonLink>
          <ButtonLink href={telLink()} variant="ghost-light" size="lg" iconLeft={<Phone className="size-5" />}>
            Call {company.phoneDisplay}
          </ButtonLink>
        </motion.div>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ delay: 0.7, duration: 0.5 }}
          className="mt-8 text-sm text-white/50"
        >
          {company.tagline}
        </motion.p>
      </nav>
    </motion.div>
  );
}
