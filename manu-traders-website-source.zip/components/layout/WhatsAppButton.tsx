"use client";

import { motion } from "framer-motion";
import { MessageCircle } from "lucide-react";
import { whatsappLink } from "@/lib/company";
import { ease } from "@/lib/motion";

/**
 * Floating WhatsApp shortcut (bottom-right).
 * Uses a soft, slow ring pulse — no blinking. Respects device safe areas.
 */
export function WhatsAppButton() {
  return (
    <motion.a
      href={whatsappLink()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with MANU Traders on WhatsApp"
      initial={{ opacity: 0, scale: 0.6, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ duration: 0.6, ease: ease.out, delay: 1.6 }}
      className="group fixed z-40 flex items-center gap-3 rounded-full"
      style={{
        right: "max(1rem, env(safe-area-inset-right))",
        bottom: "max(1rem, calc(env(safe-area-inset-bottom) + 0.75rem))",
      }}
    >
      <span className="pointer-events-none hidden translate-x-2 rounded-full bg-forest-950 px-4 py-2 text-sm font-semibold text-white opacity-0 shadow-lg transition-all duration-300 ease-out-expo group-hover:translate-x-0 group-hover:opacity-100 group-focus-visible:translate-x-0 group-focus-visible:opacity-100 md:block">
        Chat on WhatsApp
      </span>
      <span className="relative grid size-14 place-items-center rounded-full bg-leaf-600 text-white shadow-[0_12px_30px_-8px_rgba(0,82,54,0.6)] ring-4 ring-white/70 transition-transform duration-300 ease-out-expo group-hover:scale-105 md:size-[3.75rem]">
        <span
          aria-hidden="true"
          className="absolute inset-0 rounded-full bg-leaf-300 motion-safe:animate-soft-pulse"
        />
        <MessageCircle className="relative size-6" aria-hidden="true" strokeWidth={2.2} />
      </span>
    </motion.a>
  );
}
