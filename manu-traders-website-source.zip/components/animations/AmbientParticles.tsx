import type { CSSProperties } from "react";
import { cn } from "@/lib/utils";

/**
 * Lightweight drifting pollen / dust particles (pure CSS, no JS).
 * Positions are deterministic to avoid hydration mismatches.
 */
const PARTICLES = Array.from({ length: 22 }, (_, i) => {
  const seed = (i * 9301 + 49297) % 233280;
  const r = (n: number) => ((seed * (n + 1)) % 1000) / 1000;
  return {
    left: `${(r(1) * 100).toFixed(2)}%`,
    top: `${(20 + r(2) * 75).toFixed(2)}%`,
    size: 1.5 + r(3) * 3,
    delay: `${(r(4) * -14).toFixed(2)}s`,
    duration: `${(10 + r(5) * 10).toFixed(2)}s`,
    x: `${(-30 + r(6) * 60).toFixed(0)}px`,
    y: `${(-30 - r(7) * 70).toFixed(0)}px`,
    o: (0.25 + r(8) * 0.5).toFixed(2),
  };
});

export function AmbientParticles({ className }: { className?: string }) {
  return (
    <div aria-hidden="true" className={cn("pointer-events-none absolute inset-0 overflow-hidden", className)}>
      {PARTICLES.map((p, i) => (
        <span
          key={i}
          className="absolute rounded-full bg-gold-100 shadow-[0_0_8px_rgba(255,220,195,0.7)] motion-safe:animate-drift"
          style={
            {
              left: p.left,
              top: p.top,
              width: p.size,
              height: p.size,
              animationDelay: p.delay,
              animationDuration: p.duration,
              opacity: p.o,
              "--p-x": p.x,
              "--p-y": p.y,
              "--p-o": p.o,
            } as CSSProperties
          }
        />
      ))}
    </div>
  );
}
