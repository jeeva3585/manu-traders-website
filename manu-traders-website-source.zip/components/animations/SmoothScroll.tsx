"use client";

import Lenis from "lenis";
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

const LenisContext = createContext<Lenis | null>(null);

/** Access the Lenis instance (null on touch devices / reduced motion). */
export function useLenis(): Lenis | null {
  return useContext(LenisContext);
}

/**
 * Smooth scrolling with Lenis.
 * - Disabled for visitors who prefer reduced motion.
 * - Touch devices keep native momentum scrolling (Lenis `syncTouch` off).
 * - Anchor links (#section) are handled by Lenis with an offset for the fixed header.
 */
export function SmoothScroll({ children }: { children: ReactNode }) {
  const [lenis, setLenis] = useState<Lenis | null>(null);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;

    const instance = new Lenis({
      duration: 1.1,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      smoothWheel: true,
      anchors: { offset: -88 },
      autoRaf: true,
    });
    // eslint-disable-next-line react-hooks/set-state-in-effect -- instance must be created on the client after mount
    setLenis(instance);

    return () => {
      instance.destroy();
      setLenis(null);
    };
  }, []);

  return <LenisContext.Provider value={lenis}>{children}</LenisContext.Provider>;
}
