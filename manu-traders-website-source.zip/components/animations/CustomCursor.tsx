"use client";

import { motion, useMotionValue, useSpring } from "framer-motion";
import { useEffect, useState } from "react";
import { useFinePointer, usePrefersReducedMotion } from "@/hooks/useMediaQuery";

/**
 * Subtle desktop-only cursor follower. The native cursor is never hidden.
 * It grows over elements marked with `data-cursor="view"` (e.g. product cards).
 * Disabled on touch devices and for reduced-motion users.
 */
export function CustomCursor() {
  const finePointer = useFinePointer();
  const reduce = usePrefersReducedMotion();
  const enabled = finePointer && !reduce;

  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const sx = useSpring(x, { stiffness: 420, damping: 38, mass: 0.6 });
  const sy = useSpring(y, { stiffness: 420, damping: 38, mass: 0.6 });
  const [mode, setMode] = useState<"default" | "view" | "hidden">("hidden");

  useEffect(() => {
    if (!enabled) return;
    const move = (e: PointerEvent) => {
      x.set(e.clientX);
      y.set(e.clientY);
      const target = e.target as HTMLElement | null;
      const hover = target?.closest<HTMLElement>("[data-cursor]");
      setMode(hover?.dataset.cursor === "view" ? "view" : "default");
    };
    const leave = () => setMode("hidden");
    window.addEventListener("pointermove", move, { passive: true });
    document.documentElement.addEventListener("pointerleave", leave);
    return () => {
      window.removeEventListener("pointermove", move);
      document.documentElement.removeEventListener("pointerleave", leave);
    };
  }, [enabled, x, y]);

  if (!enabled) return null;

  const size = mode === "view" ? 72 : 28;

  return (
    <motion.div
      aria-hidden="true"
      className="pointer-events-none fixed left-0 top-0 z-[100] flex items-center justify-center rounded-full border border-leaf-600/50 mix-blend-multiply"
      style={{ x: sx, y: sy, translateX: "-50%", translateY: "-50%" }}
      animate={{
        width: size,
        height: size,
        opacity: mode === "hidden" ? 0 : 1,
        backgroundColor: mode === "view" ? "rgba(108,248,187,0.85)" : "rgba(108,248,187,0)",
      }}
      transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
    >
      {mode === "view" ? (
        <span className="text-[10px] font-bold uppercase tracking-[0.14em] text-forest-950">View</span>
      ) : null}
    </motion.div>
  );
}
