"use client";

import { motion, type HTMLMotionProps, type Variants } from "framer-motion";
import { fadeUp, staggerContainer, viewportOnce } from "@/lib/motion";

type RevealProps = HTMLMotionProps<"div"> & {
  variants?: Variants;
  delay?: number;
};

/** Fades + lifts its content once when it scrolls into view. */
export function Reveal({ variants = fadeUp, delay = 0, children, ...rest }: RevealProps) {
  return (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={viewportOnce}
      variants={variants}
      transition={delay ? { delay } : undefined}
      {...rest}
    >
      {children}
    </motion.div>
  );
}

type StaggerProps = HTMLMotionProps<"div"> & {
  stagger?: number;
  delayChildren?: number;
  amount?: number;
};

/** Parent that staggers `RevealItem` children as the group enters the viewport. */
export function Stagger({
  stagger = 0.1,
  delayChildren = 0,
  amount = 0.15,
  children,
  ...rest
}: StaggerProps) {
  return (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, amount }}
      variants={staggerContainer(stagger, delayChildren)}
      {...rest}
    >
      {children}
    </motion.div>
  );
}

export function RevealItem({ variants = fadeUp, children, ...rest }: HTMLMotionProps<"div"> & { variants?: Variants }) {
  return (
    <motion.div variants={variants} {...rest}>
      {children}
    </motion.div>
  );
}
