"use client";

import { motion } from "framer-motion";
import type { ElementType } from "react";
import { ease } from "@/lib/motion";
import { cn } from "@/lib/utils";

type TextRevealProps = {
  /** Each entry renders on its own line. */
  lines: string[];
  as?: ElementType;
  className?: string;
  lineClassName?: string;
  /** Delay before the first word animates (seconds). */
  delay?: number;
  /** "mount" animates immediately (hero), "inView" waits for the viewport. */
  trigger?: "mount" | "inView";
  /** Optional class applied to specific line indexes (e.g. accent colour). */
  accentLines?: Record<number, string>;
  id?: string;
};

/**
 * Masked word-by-word heading reveal.
 * The full text stays in the DOM as real heading text, so it is readable by
 * screen readers and search engines even before the animation runs.
 */
export function TextReveal({
  lines,
  as: Tag = "h2",
  className,
  lineClassName,
  delay = 0,
  trigger = "inView",
  accentLines,
  id,
}: TextRevealProps) {
  let wordIndex = 0;
  const animateProps =
    trigger === "mount"
      ? { initial: "hidden", animate: "visible" }
      : { initial: "hidden", whileInView: "visible", viewport: { once: true, amount: 0.5 } };

  return (
    <Tag className={className} id={id}>
      <motion.span className="block" {...animateProps}>
        {lines.map((line, li) => (
          <span key={li} className={cn("block", lineClassName, accentLines?.[li])}>
            {line.split(" ").map((word, wi, arr) => {
              const i = wordIndex++;
              return (
                <span key={wi} className="inline-block overflow-hidden pb-[0.12em] -mb-[0.12em] align-top">
                  <motion.span
                    className="inline-block will-change-transform"
                    variants={{
                      hidden: { y: "110%", opacity: 0 },
                      visible: {
                        y: "0%",
                        opacity: 1,
                        transition: { duration: 0.9, ease: ease.out, delay: delay + i * 0.06 },
                      },
                    }}
                  >
                    {word}
                  </motion.span>
                  {wi < arr.length - 1 ? " " : null}
                </span>
              );
            })}
          </span>
        ))}
      </motion.span>
    </Tag>
  );
}
