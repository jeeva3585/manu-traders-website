"use client";

import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import Image from "next/image";
import { useRef } from "react";
import { useMediaQuery } from "@/hooks/useMediaQuery";
import { cn } from "@/lib/utils";

type ParallaxImageProps = {
  src: string;
  alt: string;
  className?: string;
  imgClassName?: string;
  sizes?: string;
  /** Percentage of travel; positive moves the image slower than the page. */
  strength?: number;
  /** Extra scale-down while scrolling for a cinematic feel. */
  zoom?: boolean;
  preload?: boolean;
};

/**
 * Image with a gentle scroll parallax.
 * Parallax is reduced on small screens and removed for reduced-motion users.
 */
export function ParallaxImage({
  src,
  alt,
  className,
  imgClassName,
  sizes = "100vw",
  strength = 10,
  zoom = false,
  preload = false,
}: ParallaxImageProps) {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const isSmall = useMediaQuery("(max-width: 767px)");
  const travel = reduce ? 0 : isSmall ? strength * 0.4 : strength;

  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [`-${travel}%`, `${travel}%`]);
  const scale = useTransform(scrollYProgress, [0, 1], zoom && !reduce ? [1.18, 1.04] : [1.12, 1.12]);

  return (
    <div ref={ref} className={cn("relative overflow-hidden", className)}>
      <motion.div className="absolute inset-0 will-change-transform" style={{ y, scale }}>
        <Image
          src={src}
          alt={alt}
          fill
          sizes={sizes}
          preload={preload}
          className={cn("object-cover", imgClassName)}
        />
      </motion.div>
    </div>
  );
}
