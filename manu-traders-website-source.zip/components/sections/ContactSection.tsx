import { Clock, ExternalLink, Mail, MapPin, MessageCircle, Phone } from "lucide-react";
import type { ReactNode } from "react";
import { Reveal } from "@/components/animations/Reveal";
import { TextReveal } from "@/components/animations/TextReveal";
import { EnquiryForm } from "@/components/sections/EnquiryForm";
import { SectionLabel } from "@/components/ui/SectionLabel";
import { company } from "@/data/company";
import { formattedAddress, mailLink, telLink, whatsappLink } from "@/lib/company";

function InfoRow({ icon, title, children }: { icon: ReactNode; title: string; children: ReactNode }) {
  return (
    <div className="flex gap-4">
      <span className="mt-0.5 grid size-10 shrink-0 place-items-center rounded-xl bg-white/[0.07] text-leaf-200">{icon}</span>
      <div className="min-w-0">
        <h3 className="font-display text-lg font-semibold text-white">{title}</h3>
        <div className="mt-1 text-[0.9375rem] leading-relaxed text-white/65">{children}</div>
      </div>
    </div>
  );
}

export function ContactSection() {
  return (
    <section id="contact" aria-labelledby="contact-title" className="section-y relative bg-cream-100">
      <div className="container-site grid gap-6 lg:grid-cols-12 lg:gap-8">
        {/* Business details */}
        <Reveal className="on-dark relative overflow-hidden rounded-[2rem] bg-forest-950 p-8 text-white shadow-[0_40px_80px_-40px_rgba(0,23,11,0.7)] sm:p-10 lg:col-span-5">
          <div aria-hidden="true" className="pointer-events-none absolute -right-24 -top-24 size-72 rounded-full bg-leaf-600/25 blur-3xl" />
          <SectionLabel tone="glass">Contact {company.companyName}</SectionLabel>
          <TextReveal id="contact-title" lines={["Get in Touch"]} className="type-display mt-6" />
          <p className="mt-4 max-w-md leading-relaxed text-white/65">
            Whether you need a product, a price or advice for your crop, our team is ready to help.
          </p>

          <address className="relative mt-10 grid gap-7 not-italic">
            <InfoRow icon={<MapPin aria-hidden="true" className="size-5" />} title="Business Address">
              {formattedAddress().map((line) => (
                <span key={line} className="block">
                  {line}
                </span>
              ))}
            </InfoRow>
            <InfoRow icon={<Phone aria-hidden="true" className="size-5" />} title="Phone Number">
              <a href={telLink()} className="underline-offset-4 hover:text-white hover:underline">
                {company.phoneDisplay}
              </a>
            </InfoRow>
            <InfoRow icon={<MessageCircle aria-hidden="true" className="size-5" />} title="WhatsApp">
              <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="underline-offset-4 hover:text-white hover:underline">
                {company.whatsappDisplay}
              </a>
            </InfoRow>
            <InfoRow icon={<Mail aria-hidden="true" className="size-5" />} title="Email">
              <a href={mailLink()} className="break-all underline-offset-4 hover:text-white hover:underline">
                {company.email}
              </a>
            </InfoRow>
            <InfoRow icon={<Clock aria-hidden="true" className="size-5" />} title="Business Hours">
              {company.businessHours.map((h) => (
                <span key={h.days} className="block">
                  {h.days}: {h.time}
                </span>
              ))}
            </InfoRow>
          </address>
        </Reveal>

        <div className="grid gap-6 lg:col-span-7">
          {/* Enquiry form */}
          <Reveal delay={0.1} className="rounded-[2rem] bg-cream-50 p-7 ring-1 ring-cream-400/80 sm:p-10">
            <h3 className="font-display text-2xl font-semibold tracking-[-0.01em] text-forest-950">Send an Enquiry</h3>
            <p className="mt-2 text-ink-muted">Share a few details and we&rsquo;ll get back to you.</p>
            <div className="mt-8">
              <EnquiryForm />
            </div>
          </Reveal>

          {/* Google Maps */}
          <Reveal delay={0.15} className="overflow-hidden rounded-[2rem] ring-1 ring-cream-400/80">
            {company.mapsEmbedURL ? (
              <iframe
                title={`${company.companyName} location on Google Maps`}
                src={company.mapsEmbedURL}
                className="block h-72 w-full border-0 lg:h-80"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                allowFullScreen
              />
            ) : (
              <div className="relative flex h-60 flex-col items-center justify-center gap-3 bg-cream-200 p-6 text-center">
                <div
                  aria-hidden="true"
                  className="absolute inset-0 opacity-50 [background-image:linear-gradient(var(--mt-cream-400)_1px,transparent_1px),linear-gradient(90deg,var(--mt-cream-400)_1px,transparent_1px)] [background-size:32px_32px]"
                />
                <span className="relative grid size-12 place-items-center rounded-full bg-forest-950 text-leaf-200">
                  <MapPin aria-hidden="true" className="size-5" />
                </span>
                <p className="relative font-display text-lg font-semibold text-forest-950">Google Maps location</p>
                <p className="relative max-w-sm text-sm text-ink-soft">
                  Placeholder — add the map embed URL in <code className="rounded bg-white px-1.5 py-0.5 text-xs">data/company.ts</code>.
                </p>
                {company.mapsURL ? (
                  <a
                    href={company.mapsURL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="relative inline-flex items-center gap-1.5 text-sm font-semibold text-leaf-600 hover:underline"
                  >
                    Open in Google Maps <ExternalLink aria-hidden="true" className="size-4" />
                  </a>
                ) : null}
              </div>
            )}
          </Reveal>
        </div>
      </div>
    </section>
  );
}
