import { ArrowUpRight, Sprout } from "lucide-react";
import Image from "next/image";
import { RevealItem, Stagger } from "@/components/animations/Reveal";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { productCategories, type ProductCategory } from "@/data/products";
import { whatsappLink } from "@/lib/company";

function ProductCard({ product, index }: { product: ProductCategory; index: number }) {
  const Icon = product.icon;
  return (
    <a
      href={whatsappLink(`Hello MANU Traders, I would like to know more about your ${product.title.toLowerCase()}.`)}
      target="_blank"
      rel="noopener noreferrer"
      data-cursor="view"
      aria-label={`${product.title} — ask about availability on WhatsApp`}
      className="group relative flex h-full flex-col overflow-hidden rounded-[1.75rem] bg-cream-50 ring-1 ring-inset ring-cream-400/70 transition-[box-shadow,transform,background-color] duration-500 ease-out-expo hover:-translate-y-1.5 hover:bg-white hover:shadow-[0_30px_60px_-30px_rgba(0,23,11,0.4)] hover:ring-2 hover:ring-leaf-600/25"
    >
      <div className="relative m-2 aspect-[16/11] overflow-hidden rounded-[1.35rem]">
        <Image
          src={product.image}
          alt={product.imageAlt}
          fill
          sizes="(min-width: 1280px) 400px, (min-width: 768px) 45vw, 92vw"
          className="object-cover transition-transform duration-[1.2s] ease-out-expo group-hover:scale-[1.07]"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-t from-forest-950/55 via-forest-950/0 to-transparent opacity-70 transition-opacity duration-500 group-hover:opacity-100"
        />
        <span className="absolute left-3 top-3 grid size-11 place-items-center rounded-xl bg-cream-50/90 text-leaf-600 shadow-sm backdrop-blur-md">
          <Icon aria-hidden="true" className="size-5" />
        </span>
        <span className="absolute right-3 top-3 rounded-full bg-forest-950/70 px-3 py-1.5 text-[0.7rem] font-semibold tracking-[0.04em] text-white backdrop-blur-md">
          {product.badge}
        </span>
        <span aria-hidden="true" className="absolute bottom-3 left-4 font-display text-sm font-semibold text-white/85">
          {String(index + 1).padStart(2, "0")}
        </span>
      </div>

      <div className="flex flex-1 flex-col px-6 pb-6 pt-4">
        <h3 className="type-h3 text-forest-950">{product.title}</h3>
        <p className="mt-3 leading-relaxed text-ink-muted">{product.description}</p>
        <ul className="mt-5 flex flex-wrap gap-2" aria-label={`${product.title} examples`}>
          {product.tags.map((tag) => (
            <li key={tag} className="rounded-full bg-cream-300 px-3 py-1 text-xs font-medium text-ink-muted">
              {tag}
            </li>
          ))}
        </ul>
        <div className="mt-auto flex items-center justify-between pt-7">
          <span className="text-xs font-bold uppercase tracking-[0.12em] text-leaf-600">Ask Availability</span>
          <span className="grid size-10 place-items-center rounded-full bg-cream-300 text-forest-950 transition-all duration-500 ease-out-expo group-hover:rotate-45 group-hover:bg-leaf-200">
            <ArrowUpRight aria-hidden="true" className="size-5" />
          </span>
        </div>
      </div>
    </a>
  );
}

export function ProductsSection() {
  return (
    <section id="products" aria-labelledby="products-title" className="section-y relative bg-cream-200">
      <div className="container-site">
        <SectionHeader
          id="products-title"
          eyebrow="Our Product Range"
          eyebrowIcon={<Sprout aria-hidden="true" className="size-3.5" />}
          title={["Everything Your Farm Needs"]}
          description="Trusted agricultural products selected for healthier crops and better productivity."
        />

        <Stagger className="mt-14 grid gap-5 md:grid-cols-2 lg:mt-16 lg:gap-6 xl:grid-cols-3" stagger={0.12} amount={0.08}>
          {productCategories.map((product, i) => (
            <RevealItem key={product.slug} className="h-full">
              <ProductCard product={product} index={i} />
            </RevealItem>
          ))}
        </Stagger>
      </div>
    </section>
  );
}
