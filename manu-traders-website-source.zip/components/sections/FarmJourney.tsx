"use client";

import { motion, useScroll, useSpring } from "framer-motion";
import { CircleCheck, Leaf, TrendingUp } from "lucide-react";
import Image from "next/image";
import { useRef } from "react";
import { Reveal } from "@/components/animations/Reveal";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { journeyStages } from "@/data/journey";
import { ease } from "@/lib/motion";
import { cn } from "@/lib/utils";

export function FarmJourney() {
  const trackRef = useRef<HTMLOListElement>(null);
  const { scrollYProgress } = useScroll({ target: trackRef, offset: ["start 85%", "end 60%"] });
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 30, mass: 0.4 });

  return (
    <section aria-labelledby="journey-title" className="section-y relative overflow-hidden bg-cream-200">
      <div className="container-site">
        <SectionHeader
          id="journey-title"
          align="center"
          eyebrow="The Farming Journey"
          eyebrowIcon={<TrendingUp aria-hidden="true" className="size-3.5" />}
          title={["From Soil to Harvest"]}
          description="Support for every stage of the crop cycle — the right inputs at the right time."
        />

        {/* Feature card (Stitch "Living Soils") */}
        <Reveal className="mt-14 overflow-hidden rounded-[2rem] bg-cream-50 ring-1 ring-cream-400 lg:mt-16">
          <div className="grid lg:grid-cols-2">
            <div className="relative aspect-[16/11] lg:aspect-auto lg:min-h-[22rem]">
              <Image
                src="/images/soil-preparation.webp"
                alt="Farmer holding healthy soil with young seedlings and visible roots"
                fill
                sizes="(min-width: 1024px) 50vw, 100vw"
                className="object-cover"
              />
              <p className="type-eyebrow absolute left-4 top-4 inline-flex items-center gap-2 rounded-full bg-forest-950/75 px-3.5 py-2 text-leaf-200 backdrop-blur-md">
                <Leaf aria-hidden="true" className="size-3.5" /> It Starts With Soil
              </p>
            </div>
            <div className="flex flex-col justify-center p-7 sm:p-10 lg:p-14">
              <p className="type-eyebrow text-leaf-600">Foundation of a Good Crop</p>
              <h3 className="mt-4 font-display text-[1.75rem] font-semibold leading-tight tracking-[-0.02em] text-forest-950">
                Healthy Soil Grows Stronger Crops
              </h3>
              <p className="mt-4 leading-relaxed text-ink-muted">
                Good harvests begin underground. Organic manures, soil conditioners and balanced basal nutrition help
                build a healthy root zone so crops can take up nutrients from day one.
              </p>
              <ul className="mt-6 flex flex-wrap gap-x-6 gap-y-2 text-sm text-ink-soft">
                {["Better root establishment", "Balanced nutrition"].map((t) => (
                  <li key={t} className="flex items-center gap-2">
                    <CircleCheck aria-hidden="true" className="size-4 text-leaf-600" />
                    {t}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </Reveal>

        {/* Timeline */}
        <div className="relative mt-16 lg:mt-20">
          {/* Horizontal track (desktop) */}
          <div aria-hidden="true" className="absolute left-[10%] right-[10%] top-6 hidden h-[2px] rounded-full bg-forest-950/10 lg:block">
            <motion.div className="h-full origin-left rounded-full bg-gradient-to-r from-leaf-600 via-leaf-300 to-gold-500" style={{ scaleX: progress }} />
          </div>
          {/* Vertical track (mobile / tablet) */}
          <div aria-hidden="true" className="absolute bottom-6 left-6 top-6 w-[2px] rounded-full bg-forest-950/10 lg:hidden">
            <motion.div className="w-full origin-top rounded-full bg-gradient-to-b from-leaf-600 via-leaf-300 to-gold-500" style={{ scaleY: progress, height: "100%" }} />
          </div>

          <ol ref={trackRef} className="relative grid gap-6 lg:grid-cols-5 lg:gap-5">
            {journeyStages.map((stage, i) => {
              const Icon = stage.icon;
              const last = i === journeyStages.length - 1;
              return (
                <motion.li
                  key={stage.number}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.4 }}
                  transition={{ duration: 0.7, ease: ease.out, delay: i * 0.08 }}
                  className="relative grid grid-cols-[3rem_1fr] gap-4 lg:flex lg:flex-col lg:items-center lg:gap-6"
                >
                  <span
                    className={cn(
                      "relative z-10 grid size-12 place-items-center rounded-full ring-8 ring-cream-200",
                      last ? "bg-forest-950 text-leaf-200" : "bg-leaf-200 text-forest-950",
                    )}
                  >
                    <Icon aria-hidden="true" className="size-5" />
                  </span>
                  <article
                    className={cn(
                      "flex h-full w-full flex-col rounded-[1.5rem] p-6 transition-all duration-500 ease-out-expo hover:-translate-y-1",
                      last
                        ? "on-dark bg-forest-950 text-white shadow-[0_30px_60px_-30px_rgba(0,23,11,0.7)]"
                        : "bg-cream-50 hover:shadow-[0_24px_50px_-30px_rgba(0,23,11,0.35)]",
                    )}
                  >
                    <p className={cn("type-eyebrow", last ? "text-leaf-200" : "text-leaf-600")}>Stage {stage.number}</p>
                    <h3 className={cn("mt-3 font-display text-xl font-semibold tracking-[-0.01em]", last ? "text-white" : "text-forest-950")}>
                      {stage.title}
                    </h3>
                    <p className={cn("mt-2.5 text-[0.9375rem] leading-relaxed", last ? "text-white/70" : "text-ink-muted")}>
                      {stage.text}
                    </p>
                    <p className={cn("mt-auto pt-5 text-xs font-semibold", last ? "text-leaf-200" : "text-ink-soft")}>
                      Focus: {stage.focus}
                    </p>
                  </article>
                </motion.li>
              );
            })}
          </ol>
        </div>
      </div>
    </section>
  );
}
