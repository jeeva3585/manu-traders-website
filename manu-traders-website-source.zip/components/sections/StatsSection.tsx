import { CountUp } from "@/components/animations/CountUp";
import { RevealItem, Stagger } from "@/components/animations/Reveal";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { stats } from "@/data/stats";

export function StatsSection() {
  return (
    <section aria-labelledby="stats-title" className="on-dark section-y relative overflow-hidden bg-forest-950 text-white">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 top-0 h-[30rem] w-[60rem] -translate-x-1/2 rounded-full bg-leaf-600/25 blur-[120px]"
      />
      <div className="container-site relative">
        <SectionHeader
          id="stats-title"
          align="center"
          tone="dark"
          eyebrow="Our Commitment"
          title={["Rooted in Farming Communities"]}
          description="Dedicated to the growth and prosperity of the farmers we serve."
        />

        <Stagger className="mt-14 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:mt-16 lg:grid-cols-4 lg:gap-6" stagger={0.12}>
          {stats.map((s) => (
            <RevealItem
              key={s.label}
              className="group relative overflow-hidden rounded-[1.75rem] bg-gradient-to-b from-white/[0.07] to-white/[0.02] p-8 text-center ring-1 ring-inset ring-white/10 transition-colors duration-500 hover:ring-leaf-200/30"
            >
              <p className="font-display text-[3.25rem] font-bold leading-none tracking-[-0.04em] text-leaf-200 lg:text-6xl">
                {s.value !== null ? <CountUp value={s.value} suffix={s.suffix} /> : s.display}
              </p>
              <p className="mt-4 font-display text-lg font-semibold">{s.label}</p>
              <p className="mt-1 text-sm text-white/55">{s.sub}</p>
            </RevealItem>
          ))}
        </Stagger>
      </div>
    </section>
  );
}
