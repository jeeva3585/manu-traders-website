"use client";

import { useEffect, useRef, useState, type Ref } from "react";
import { useLenis } from "@/components/animations/SmoothScroll";
import { SectionLabel } from "@/components/ui/SectionLabel";
import { growthStages } from "@/data/journey";
import { cn } from "@/lib/utils";

/**
 * Scroll-driven crop growth motion graphic: Seed → Root → Sprout → Plant → Healthy Crop → Harvest.
 *
 * - Pure SVG, animated with a GSAP timeline scrubbed by ScrollTrigger (GSAP is loaded lazily
 *   only when this section approaches the viewport).
 * - The markup renders the fully grown plant by default, so without JavaScript or with
 *   reduced motion the visitor still sees the complete illustration and all stage text.
 */
export function GrowthStory() {
  const sectionRef = useRef<HTMLElement>(null);
  const pinRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const [active, setActive] = useState(growthStages.length - 1);
  const [animated, setAnimated] = useState(false);
  const lenis = useLenis();

  useEffect(() => {
    const section = sectionRef.current;
    const pin = pinRef.current;
    const svg = svgRef.current;
    if (!section || !pin || !svg) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    let cleanup: (() => void) | undefined;
    let cancelled = false;

    const load = async () => {
      const [{ gsap }, { ScrollTrigger }] = await Promise.all([import("gsap"), import("gsap/ScrollTrigger")]);
      if (cancelled) return;
      gsap.registerPlugin(ScrollTrigger);
      setAnimated(true);
      setActive(0);

      const q = (sel: string) => svg.querySelectorAll<SVGElement>(sel);
      const isMobile = window.matchMedia("(max-width: 767px)").matches;

      const ctx = gsap.context(() => {
        // Initial (un-grown) state
        gsap.set(q("[data-draw]"), { strokeDashoffset: 1 });
        gsap.set(q("[data-seed]"), { scale: 0, opacity: 0, transformOrigin: "50% 50%" });
        gsap.set(q("[data-leaf]"), { scale: 0, opacity: 0 });
        gsap.set(q("[data-grain]"), { scale: 0, opacity: 0, transformOrigin: "50% 100%" });
        gsap.set(q("[data-sun]"), { opacity: 0.25, scale: 0.85, transformOrigin: "50% 50%" });
        gsap.set(q("[data-ground-glow]"), { opacity: 0 });

        const tl = gsap.timeline({
          defaults: { ease: "power2.out" },
          scrollTrigger: {
            trigger: section,
            start: "top top",
            end: isMobile ? "+=170%" : "+=240%",
            scrub: 0.8,
            pin,
            anticipatePin: 1,
            onUpdate: (self) => {
              const idx = Math.min(growthStages.length - 1, Math.floor(self.progress * growthStages.length));
              setActive((prev) => (prev === idx ? prev : idx));
            },
          },
        });

        tl.to(q("[data-seed]"), { scale: 1, opacity: 1, duration: 0.6, ease: "back.out(1.6)" })
          .to(q("[data-ground-glow]"), { opacity: 1, duration: 0.5 }, "<")
          .to(q("[data-draw='root']"), { strokeDashoffset: 0, duration: 1, stagger: 0.08 })
          .to(q("[data-draw='sprout']"), { strokeDashoffset: 0, duration: 0.7 })
          .to(q("[data-leaf='cotyledon']"), { scale: 1, opacity: 1, duration: 0.5, stagger: 0.1 }, "-=0.2")
          .to(q("[data-draw='stem']"), { strokeDashoffset: 0, duration: 1 })
          .to(q("[data-leaf='true']"), { scale: 1, opacity: 1, duration: 0.6, stagger: 0.12 }, "-=0.6")
          .to(q("[data-sun]"), { opacity: 1, scale: 1, duration: 0.8 }, "-=0.4")
          .to(q("[data-draw='panicle']"), { strokeDashoffset: 0, duration: 0.6 })
          .to(q("[data-grain]"), { scale: 1, opacity: 1, duration: 0.6, stagger: 0.03 }, "-=0.3");
      }, section);

      const onLenisScroll = () => ScrollTrigger.update();
      lenis?.on("scroll", onLenisScroll);
      ScrollTrigger.refresh();

      cleanup = () => {
        lenis?.off("scroll", onLenisScroll);
        ctx.revert();
      };
    };

    // Load GSAP only when the section is close to the viewport.
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          io.disconnect();
          void load();
        }
      },
      { rootMargin: "100% 0px" },
    );
    io.observe(section);

    return () => {
      cancelled = true;
      io.disconnect();
      cleanup?.();
    };
  }, [lenis]);

  const current = growthStages[active];

  return (
    <section ref={sectionRef} aria-labelledby="growth-title" className="relative bg-forest-900 text-white">
      <div ref={pinRef} className="on-dark relative flex min-h-[100svh] items-center overflow-hidden pb-10 pt-24 lg:py-24">
        <div aria-hidden="true" className="pointer-events-none absolute -left-40 top-1/4 size-[40rem] rounded-full bg-leaf-600/20 blur-3xl" />

        <div className="container-site relative grid items-center gap-6 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-5">
            <SectionLabel tone="glass">The Life of a Crop</SectionLabel>
            <h2 id="growth-title" className="type-display mt-6">
              From Seed <span className="text-leaf-200">to Harvest.</span>
            </h2>
            <p className="type-lead mt-5 hidden max-w-md text-white/65 sm:block">
              Every stage of growth needs something different. Scroll to watch a crop grow — and see where the right
              inputs make a difference.
            </p>

            <ol className="mt-10 hidden gap-1 lg:grid" aria-label="Growth stages">
              {growthStages.map((s, i) => {
                const isActive = !animated || i === active;
                const done = animated && i < active;
                return (
                  <li
                    key={s.key}
                    aria-current={animated && i === active ? "step" : undefined}
                    className={cn(
                      "grid grid-cols-[2.5rem_1fr] items-start gap-3 rounded-2xl px-4 py-3 transition-all duration-500 ease-out-expo",
                      animated && i === active && "bg-white/[0.06]",
                    )}
                  >
                    <span
                      className={cn(
                        "mt-0.5 grid size-7 place-items-center rounded-full text-xs font-bold transition-colors duration-500",
                        isActive ? "bg-leaf-200 text-forest-950" : done ? "bg-leaf-600 text-white" : "bg-white/10 text-white/50",
                      )}
                    >
                      {i + 1}
                    </span>
                    <span>
                      <span
                        className={cn(
                          "block font-display text-lg font-semibold transition-colors duration-500",
                          isActive ? "text-white" : "text-white/45",
                        )}
                      >
                        {s.label}
                      </span>
                      <span
                        className={cn(
                          "grid transition-[grid-template-rows,opacity] duration-500 ease-out-expo",
                          isActive ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
                        )}
                      >
                        <span className="overflow-hidden text-sm leading-relaxed text-white/60">{s.text}</span>
                      </span>
                    </span>
                  </li>
                );
              })}
            </ol>
          </div>

          <div className="relative lg:col-span-7">
            <div className="relative mx-auto aspect-[5/6] w-full max-w-[min(34rem,calc(48svh*5/6))] overflow-hidden lg:max-w-[34rem] rounded-[2rem] bg-[linear-gradient(180deg,#0f2d1e_0%,#163b29_58%,#2b1d12_58.2%,#1d140c_100%)] ring-1 ring-white/10">
              <GrowthIllustration ref={svgRef} />
            </div>
            {/* Progress bar */}
            <div className="mx-auto mt-5 flex max-w-[34rem] gap-1.5" aria-hidden="true">
              {growthStages.map((s, i) => (
                <span
                  key={s.key}
                  className={cn(
                    "h-1 flex-1 rounded-full transition-colors duration-500",
                    i <= active ? "bg-leaf-200" : "bg-white/15",
                  )}
                />
              ))}
            </div>
            {/* Mobile / tablet stage readout */}
            <div className="mx-auto mt-4 max-w-[34rem] rounded-2xl bg-white/[0.06] p-4 ring-1 ring-white/10 lg:hidden">
              <p className="type-eyebrow text-leaf-200">
                Stage {active + 1} / {growthStages.length} · {current.label}
              </p>
              <p className="mt-1.5 text-sm text-white/70">{current.text}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/** Minimal, elegant crop illustration. Default attributes = fully grown state. */
function GrowthIllustration({ ref }: { ref: Ref<SVGSVGElement> }) {
  const grains = Array.from({ length: 9 }, (_, i) => i);
  return (
    <svg
      ref={ref}
      viewBox="0 0 400 480"
      className="absolute inset-0 size-full"
      role="img"
      aria-label="Illustration of a crop growing from a seed in the soil to a mature plant with grain ready for harvest"
    >
      <defs>
        <radialGradient id="g-sun" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0%" stopColor="#ffdcc3" stopOpacity="0.95" />
          <stop offset="45%" stopColor="#f4b860" stopOpacity="0.45" />
          <stop offset="100%" stopColor="#f4b860" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="g-ground" cx="0.5" cy="0" r="0.6">
          <stop offset="0%" stopColor="#6cf8bb" stopOpacity="0.28" />
          <stop offset="100%" stopColor="#6cf8bb" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="g-leaf" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#4edea3" />
          <stop offset="100%" stopColor="#1f8a5f" />
        </linearGradient>
        <linearGradient id="g-grain" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#ffdcc3" />
          <stop offset="100%" stopColor="#e9a23b" />
        </linearGradient>
      </defs>

      {/* Sun */}
      <circle data-sun cx="318" cy="84" r="70" fill="url(#g-sun)" />

      {/* Soil surface + texture */}
      <path d="M0 279 C 80 272, 140 284, 200 278 S 330 272, 400 280 L400 480 L0 480 Z" fill="#24180e" />
      <path d="M0 279 C 80 272, 140 284, 200 278 S 330 272, 400 280" fill="none" stroke="#4a3320" strokeWidth="2" />
      {[
        [40, 320, 2.2], [92, 356, 1.6], [150, 410, 2], [268, 330, 1.8], [330, 380, 2.4], [360, 440, 1.6], [70, 440, 1.8], [240, 450, 1.5],
      ].map(([cx, cy, r], i) => (
        <circle key={i} cx={cx} cy={cy} r={r} fill="#5b4129" opacity="0.7" />
      ))}
      <ellipse data-ground-glow cx="200" cy="300" rx="150" ry="70" fill="url(#g-ground)" />

      {/* Roots */}
      <g stroke="#d9c3a5" strokeLinecap="round" fill="none" opacity="0.85">
        <path data-draw="root" pathLength={1} strokeDasharray="1" strokeDashoffset="0" strokeWidth="3" d="M200 312 C 199 340, 204 368, 198 404 S 192 440, 196 462" />
        <path data-draw="root" pathLength={1} strokeDasharray="1" strokeDashoffset="0" strokeWidth="2" d="M200 324 C 186 340, 168 352, 150 378 S 128 410, 118 430" />
        <path data-draw="root" pathLength={1} strokeDasharray="1" strokeDashoffset="0" strokeWidth="2" d="M201 326 C 216 344, 236 352, 252 376 S 274 404, 286 428" />
        <path data-draw="root" pathLength={1} strokeDasharray="1" strokeDashoffset="0" strokeWidth="1.4" d="M198 360 C 184 372, 172 380, 160 400" />
        <path data-draw="root" pathLength={1} strokeDasharray="1" strokeDashoffset="0" strokeWidth="1.4" d="M199 372 C 214 384, 226 396, 232 414" />
        <path data-draw="root" pathLength={1} strokeDasharray="1" strokeDashoffset="0" strokeWidth="1.1" d="M152 376 C 140 380, 128 378, 116 384" />
        <path data-draw="root" pathLength={1} strokeDasharray="1" strokeDashoffset="0" strokeWidth="1.1" d="M250 374 C 262 372, 276 376, 290 372" />
      </g>

      {/* Seed */}
      <g data-seed>
        <ellipse cx="200" cy="308" rx="11" ry="7.5" fill="#c58a3a" transform="rotate(-18 200 308)" />
        <path d="M193 306 Q 200 302 207 307" stroke="#f4b860" strokeWidth="1.4" fill="none" />
      </g>

      {/* Sprout (emergence) + main stem */}
      <path data-draw="sprout" pathLength={1} strokeDasharray="1" strokeDashoffset="0" d="M200 304 C 200 292, 199 282, 200 262" stroke="#4edea3" strokeWidth="4.5" strokeLinecap="round" fill="none" />
      <path data-draw="stem" pathLength={1} strokeDasharray="1" strokeDashoffset="0" d="M200 262 C 201 220, 197 180, 202 136 S 204 104, 206 92" stroke="#3cc48e" strokeWidth="4.5" strokeLinecap="round" fill="none" />

      {/* Cotyledons */}
      <path data-leaf="cotyledon" style={{ transformOrigin: "200px 268px" }} d="M200 268 C 186 258, 172 260, 164 266 C 176 274, 190 274, 200 268 Z" fill="url(#g-leaf)" />
      <path data-leaf="cotyledon" style={{ transformOrigin: "200px 268px" }} d="M200 268 C 214 258, 228 260, 236 266 C 224 274, 210 274, 200 268 Z" fill="url(#g-leaf)" />

      {/* True leaves — long, grass-like blades typical of paddy / cereal crops */}
      <path data-leaf="true" style={{ transformOrigin: "200px 236px" }} d="M200 236 C 170 222, 132 220, 96 236 C 132 230, 168 236, 200 244 Z" fill="url(#g-leaf)" />
      <path data-leaf="true" style={{ transformOrigin: "200px 214px" }} d="M200 214 C 232 196, 274 192, 312 206 C 274 202, 234 210, 201 222 Z" fill="url(#g-leaf)" />
      <path data-leaf="true" style={{ transformOrigin: "200px 186px" }} d="M200 186 C 176 164, 142 150, 108 154 C 142 160, 174 176, 199 196 Z" fill="url(#g-leaf)" />
      <path data-leaf="true" style={{ transformOrigin: "201px 160px" }} d="M201 160 C 226 140, 258 128, 292 130 C 258 136, 228 152, 202 170 Z" fill="url(#g-leaf)" />
      <path data-leaf="true" style={{ transformOrigin: "202px 132px" }} d="M202 132 C 188 112, 170 98, 150 92 C 170 104, 186 120, 201 142 Z" fill="url(#g-leaf)" />

      {/* Panicle / grain head */}
      <path data-draw="panicle" pathLength={1} strokeDasharray="1" strokeDashoffset="0" d="M206 94 C 214 76, 228 62, 246 56" stroke="#e9a23b" strokeWidth="2.4" strokeLinecap="round" fill="none" />
      {grains.map((i) => {
        const t = i / (grains.length - 1);
        const x = 206 + t * 40 - Math.sin(t * Math.PI) * 4;
        const y = 94 - t * 38 + Math.sin(t * Math.PI) * 2;
        const side = i % 2 === 0 ? -1 : 1;
        return (
          <ellipse
            key={i}
            data-grain
            cx={x + side * 5}
            cy={y - 4}
            rx="3.6"
            ry="6.5"
            fill="url(#g-grain)"
            transform={`rotate(${side * 32 + 40} ${x + side * 5} ${y - 4})`}
          />
        );
      })}
    </svg>
  );
}
