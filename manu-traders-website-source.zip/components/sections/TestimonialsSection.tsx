"use client";

import { useReducedMotion } from "framer-motion";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { Reveal } from "@/components/animations/Reveal";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { testimonials } from "@/data/testimonials";
import { cn } from "@/lib/utils";

const AUTOPLAY_MS = 7000;

function initials(name: string) {
  return name
    .split(/\s+/)
    .map((p) => p[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

/**
 * Testimonial slider built on native scroll-snap (swipeable, keyboard friendly).
 * Slow, optional autoplay that pauses on hover, focus, touch, hidden tabs and reduced motion.
 */
export function TestimonialsSection() {
  const trackRef = useRef<HTMLUListElement>(null);
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const reduce = useReducedMotion();
  const count = testimonials.length;

  const goTo = useCallback(
    (i: number) => {
      const track = trackRef.current;
      if (!track) return;
      const next = (i + count) % count;
      const slide = track.children[next] as HTMLElement | undefined;
      if (slide) track.scrollTo({ left: slide.offsetLeft - track.offsetLeft, behavior: reduce ? "auto" : "smooth" });
    },
    [count, reduce],
  );

  // Track which slide is closest to the start of the viewport.
  useEffect(() => {
    const track = trackRef.current;
    if (!track) return;
    let frame = 0;
    const onScroll = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const slides = Array.from(track.children) as HTMLElement[];
        const left = track.scrollLeft;
        let best = 0;
        let bestDist = Infinity;
        slides.forEach((s, i) => {
          const d = Math.abs(s.offsetLeft - track.offsetLeft - left);
          if (d < bestDist) {
            bestDist = d;
            best = i;
          }
        });
        setIndex(best);
      });
    };
    track.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      track.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(frame);
    };
  }, []);

  useEffect(() => {
    if (reduce || paused) return;
    const id = window.setInterval(() => {
      if (document.visibilityState === "visible") goTo(index + 1);
    }, AUTOPLAY_MS);
    return () => window.clearInterval(id);
  }, [index, paused, reduce, goTo]);

  return (
    <section aria-labelledby="testimonials-title" className="section-y relative overflow-hidden bg-cream-200">
      <div className="container-site">
        <SectionHeader
          id="testimonials-title"
          eyebrow="Farmer Voices"
          eyebrowIcon={<Quote aria-hidden="true" className="size-3.5" />}
          title={["Trusted by Farmers"]}
          description="What farmers say about working with MANU Traders."
          aside={
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => {
                  setPaused(true);
                  goTo(index - 1);
                }}
                aria-label="Previous testimonial"
                className="grid size-12 place-items-center rounded-full bg-cream-50 text-forest-950 ring-1 ring-cream-400 transition-colors hover:bg-forest-950 hover:text-white"
              >
                <ChevronLeft aria-hidden="true" className="size-5" />
              </button>
              <button
                type="button"
                onClick={() => {
                  setPaused(true);
                  goTo(index + 1);
                }}
                aria-label="Next testimonial"
                className="grid size-12 place-items-center rounded-full bg-forest-950 text-white transition-colors hover:bg-leaf-600"
              >
                <ChevronRight aria-hidden="true" className="size-5" />
              </button>
            </div>
          }
        />
      </div>

      <Reveal className="mt-12 lg:mt-14">
        <div
          className="container-site"
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
          onFocusCapture={() => setPaused(true)}
          onTouchStart={() => setPaused(true)}
        >
          <ul
            ref={trackRef}
            aria-roledescription="carousel"
            aria-label="Farmer testimonials"
            data-lenis-prevent-wheel
            className="-mx-1 -my-6 flex snap-x snap-mandatory gap-5 overflow-x-auto scroll-smooth px-1 py-6 pb-12 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
          >
            {testimonials.map((t, i) => (
              <li
                key={i}
                aria-roledescription="slide"
                aria-label={`${i + 1} of ${count}`}
                className="w-[86%] shrink-0 snap-start sm:w-[60%] lg:w-[calc((100%-2.5rem)/3)]"
              >
                <figure
                  className={cn(
                    "flex h-full flex-col rounded-[1.75rem] bg-cream-50 p-7 ring-1 ring-inset ring-cream-400/70 transition-all duration-700 ease-out-expo sm:p-8",
                    i === index ? "shadow-[0_26px_56px_-34px_rgba(0,23,11,0.45)]" : "",
                  )}
                >
                  <div className="flex items-center justify-between">
                    <Quote aria-hidden="true" className="size-8 text-leaf-200" fill="currentColor" strokeWidth={0} />
                    {t.isPlaceholder ? (
                      <span className="rounded-full bg-gold-100 px-3 py-1 text-[0.7rem] font-bold uppercase tracking-[0.1em] text-[#6e3900]">
                        Sample
                      </span>
                    ) : null}
                  </div>
                  <blockquote className="mt-6 flex-1 font-display text-[1.15rem] font-medium leading-relaxed text-forest-950">
                    <p>&ldquo;{t.feedback}&rdquo;</p>
                  </blockquote>
                  <figcaption className="mt-8 flex items-center gap-4 border-t border-cream-400/70 pt-6">
                    <span
                      aria-hidden="true"
                      className="grid size-12 shrink-0 place-items-center rounded-full bg-forest-950 text-sm font-bold text-leaf-200"
                    >
                      {initials(t.name)}
                    </span>
                    <span>
                      <span className="block font-display text-lg font-semibold text-forest-950">{t.name}</span>
                      <span className="block text-sm text-ink-soft">
                        {t.crop ? `${t.crop} Farmer · ` : ""}
                        {t.location}
                      </span>
                    </span>
                  </figcaption>
                </figure>
              </li>
            ))}
          </ul>

          <div className="mt-6 flex justify-center gap-2" role="group" aria-label="Choose testimonial">
            {testimonials.map((_, i) => (
              <button
                key={i}
                type="button"
                onClick={() => {
                  setPaused(true);
                  goTo(i);
                }}
                aria-label={`Show testimonial ${i + 1}`}
                aria-current={i === index ? "true" : undefined}
                className="grid h-6 place-items-center px-1"
              >
                <span
                  className={cn(
                    "block h-1.5 rounded-full transition-all duration-500 ease-out-expo",
                    i === index ? "w-8 bg-forest-950" : "w-1.5 bg-forest-950/25",
                  )}
                />
              </button>
            ))}
          </div>
        </div>
      </Reveal>
    </section>
  );
}
