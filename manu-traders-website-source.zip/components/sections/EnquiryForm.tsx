"use client";

import { AnimatePresence, motion } from "framer-motion";
import { CircleAlert, CircleCheck, Lock, MessageCircle, Send } from "lucide-react";
import { useId, useRef, useState, type ChangeEvent, type FormEvent, type ReactNode } from "react";
import { Button, ButtonLink } from "@/components/ui/Button";
import { whatsappLink } from "@/lib/company";
import {
  cropOptions,
  emptyEnquiry,
  enquiryToMessage,
  submitEnquiry,
  validateEnquiry,
  type EnquiryData,
  type EnquiryErrors,
} from "@/lib/enquiry";
import { ease } from "@/lib/motion";
import { cn } from "@/lib/utils";

type Status = "idle" | "submitting" | "sent" | "not-configured" | "error";

const inputBase =
  "w-full rounded-xl bg-cream-200 px-4 text-[0.9375rem] text-forest-950 ring-1 ring-inset ring-transparent placeholder:text-ink-soft/70 transition-[box-shadow,background-color] duration-300 focus:bg-white focus:outline-none focus:ring-2 focus:ring-leaf-600";

function Field({
  id,
  label,
  error,
  required,
  hint,
  children,
}: {
  id: string;
  label: string;
  error?: string;
  required?: boolean;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-2">
      <label htmlFor={id} className="text-sm font-semibold text-forest-950">
        {label}
        {required ? <span aria-hidden="true" className="text-leaf-600"> *</span> : <span className="font-normal text-ink-soft"> (optional)</span>}
      </label>
      {children}
      {hint && !error ? <p id={`${id}-hint`} className="text-xs text-ink-soft">{hint}</p> : null}
      <AnimatePresence initial={false}>
        {error ? (
          <motion.p
            id={`${id}-error`}
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="flex items-center gap-1.5 text-sm font-medium text-[#b42318]"
          >
            <CircleAlert aria-hidden="true" className="size-4 shrink-0" />
            {error}
          </motion.p>
        ) : null}
      </AnimatePresence>
    </div>
  );
}

export function EnquiryForm() {
  const uid = useId();
  const formRef = useRef<HTMLFormElement>(null);
  const [data, setData] = useState<EnquiryData>(emptyEnquiry);
  const [errors, setErrors] = useState<EnquiryErrors>({});
  const [touched, setTouched] = useState(false);
  const [status, setStatus] = useState<Status>("idle");
  const [errorMessage, setErrorMessage] = useState("");

  const id = (k: keyof EnquiryData) => `${uid}-${k}`;
  const describedBy = (k: keyof EnquiryData) => (errors[k] ? `${id(k)}-error` : undefined);

  const onChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const next = { ...data, [e.target.name]: e.target.value };
    setData(next);
    if (touched) setErrors(validateEnquiry(next));
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setTouched(true);
    const found = validateEnquiry(data);
    setErrors(found);
    const firstInvalid = Object.keys(found)[0] as keyof EnquiryData | undefined;
    if (firstInvalid) {
      formRef.current?.querySelector<HTMLElement>(`[name="${firstInvalid}"]`)?.focus();
      return;
    }
    setStatus("submitting");
    const result = await submitEnquiry(data);
    if (result.status === "error") {
      setErrorMessage(result.message);
      setStatus("error");
    } else {
      setStatus(result.status);
    }
  };

  const reset = () => {
    setData(emptyEnquiry);
    setErrors({});
    setTouched(false);
    setStatus("idle");
  };

  if (status === "sent" || status === "not-configured") {
    const sent = status === "sent";
    return (
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: ease.out }}
        role="status"
        aria-live="polite"
        className="flex h-full flex-col items-start justify-center gap-5 py-6"
      >
        <span className="grid size-14 place-items-center rounded-full bg-leaf-200 text-forest-950">
          {sent ? <CircleCheck aria-hidden="true" className="size-7" /> : <MessageCircle aria-hidden="true" className="size-7" />}
        </span>
        <h3 className="font-display text-2xl font-semibold text-forest-950">
          {sent ? "Thank you — your enquiry has been sent." : "Almost there — send your enquiry on WhatsApp"}
        </h3>
        <p className="max-w-md leading-relaxed text-ink-muted">
          {sent
            ? "Our team will contact you on the mobile number you provided."
            : "Online form delivery is being set up. Tap the button below to send the same details to MANU Traders on WhatsApp."}
        </p>
        <div className="flex flex-wrap gap-3">
          {!sent ? (
            <ButtonLink href={whatsappLink(enquiryToMessage(data))} iconLeft={<MessageCircle className="size-5" />}>
              Send on WhatsApp
            </ButtonLink>
          ) : null}
          <Button variant="ghost-dark" onClick={reset}>
            New Enquiry
          </Button>
        </div>
      </motion.div>
    );
  }

  return (
    <form ref={formRef} onSubmit={onSubmit} noValidate aria-describedby={`${uid}-form-note`} className="grid gap-5">
      <div className="grid gap-5 sm:grid-cols-2">
        <Field id={id("name")} label="Name" required error={errors.name}>
          <input
            id={id("name")}
            name="name"
            type="text"
            autoComplete="name"
            placeholder="Your full name"
            value={data.name}
            onChange={onChange}
            aria-invalid={!!errors.name}
            aria-describedby={describedBy("name")}
            aria-required="true"
            className={cn(inputBase, "h-13", errors.name && "ring-2 ring-[#b42318]/60")}
          />
        </Field>
        <Field id={id("mobile")} label="Mobile Number" required error={errors.mobile}>
          <div className="relative">
            <span aria-hidden="true" className="pointer-events-none absolute inset-y-0 left-4 flex items-center text-[0.9375rem] font-medium text-ink-soft">
              +91
            </span>
            <input
              id={id("mobile")}
              name="mobile"
              type="tel"
              inputMode="numeric"
              autoComplete="tel-national"
              placeholder="10-digit mobile number"
              value={data.mobile}
              onChange={onChange}
              maxLength={14}
              aria-invalid={!!errors.mobile}
              aria-describedby={describedBy("mobile")}
              aria-required="true"
              className={cn(inputBase, "h-13 pl-13", errors.mobile && "ring-2 ring-[#b42318]/60")}
            />
          </div>
        </Field>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <Field id={id("location")} label="Location" required error={errors.location}>
          <input
            id={id("location")}
            name="location"
            type="text"
            autoComplete="address-level2"
            placeholder="Village / Town, District"
            value={data.location}
            onChange={onChange}
            aria-invalid={!!errors.location}
            aria-describedby={describedBy("location")}
            aria-required="true"
            className={cn(inputBase, "h-13", errors.location && "ring-2 ring-[#b42318]/60")}
          />
        </Field>
        <Field id={id("crop")} label="Primary Crop">
          <select
            id={id("crop")}
            name="crop"
            value={data.crop}
            onChange={onChange}
            className={cn(inputBase, "h-13 appearance-none bg-[url('data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2216%22 height=%2216%22 fill=%22none%22 stroke=%22%23424843%22 stroke-width=%222%22 viewBox=%220 0 24 24%22><path d=%22m6 9 6 6 6-6%22/></svg>')] bg-[length:16px] bg-[right_1rem_center] bg-no-repeat pr-10")}
          >
            <option value="">Select a crop</option>
            {cropOptions.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </Field>
      </div>

      <Field id={id("message")} label="Message" required error={errors.message}>
        <textarea
          id={id("message")}
          name="message"
          rows={5}
          placeholder="Tell us what you need — e.g. product name, quantity, crop stage or the problem you are seeing."
          value={data.message}
          onChange={onChange}
          aria-invalid={!!errors.message}
          aria-describedby={describedBy("message")}
          aria-required="true"
          className={cn(inputBase, "resize-y py-3.5", errors.message && "ring-2 ring-[#b42318]/60")}
        />
      </Field>

      {status === "error" ? (
        <p role="alert" className="flex items-center gap-2 rounded-xl bg-[#fef3f2] px-4 py-3 text-sm font-medium text-[#b42318]">
          <CircleAlert aria-hidden="true" className="size-4 shrink-0" />
          {errorMessage}
        </p>
      ) : null}

      <div className="flex flex-col gap-4 pt-1 sm:flex-row sm:items-center sm:justify-between">
        <Button
          type="submit"
          size="lg"
          disabled={status === "submitting"}
          iconLeft={<Send className={cn("size-[1.1rem]", status === "submitting" && "animate-pulse")} />}
        >
          {status === "submitting" ? "Sending…" : "Send Enquiry"}
        </Button>
        <p id={`${uid}-form-note`} className="flex items-center gap-2 text-sm text-ink-soft">
          <Lock aria-hidden="true" className="size-4" />
          Your details are used only to respond to your enquiry.
        </p>
      </div>
    </form>
  );
}
