import { HandHeart, Leaf, ShieldCheck, Sprout } from "lucide-react";
import { ParallaxImage } from "@/components/animations/ParallaxImage";
import { Reveal, RevealItem, Stagger } from "@/components/animations/Reveal";
import { TextReveal } from "@/components/animations/TextReveal";
import { SectionLabel } from "@/components/ui/SectionLabel";
import { company } from "@/data/company";

const pillars = [
  { icon: ShieldCheck, title: "Quality Inputs", text: "Products from trusted sources" },
  { icon: Sprout, title: "Crop Nutrition", text: "Support for every growth stage" },
  { icon: HandHeart, title: "Farmer Support", text: "Help choosing the right product" },
];

export function AboutSection() {
  return (
    <section id="about" aria-labelledby="about-title" className="section-y relative overflow-hidden bg-cream-100">
      <div className="container-site grid items-center gap-14 lg:grid-cols-12 lg:gap-16">
        <div className="lg:col-span-7 xl:pr-6">
          <Reveal>
            <SectionLabel tone="dark">About MANU Traders</SectionLabel>
          </Reveal>
          <TextReveal
            id="about-title"
            lines={["Supporting Farmers.", "Strengthening Agriculture."]}
            className="type-h2 mt-6 text-forest-950 xl:text-[3.6rem]"
          />
          <Reveal delay={0.15}>
            <p className="type-lead mt-7 max-w-xl text-ink-muted">
              MANU Traders provides dependable agricultural inputs and farm solutions designed to help farmers
              improve productivity, protect crops and build stronger farms.
            </p>
          </Reveal>
          <Reveal delay={0.25}>
            <p className="mt-5 max-w-xl leading-relaxed text-ink-soft">
              From the first soil preparation to the final harvest, we work alongside farmers in {company.region}{" "}
              with the products, information and support each season needs.
            </p>
          </Reveal>

          <Stagger className="mt-10 grid gap-3 sm:grid-cols-3" stagger={0.1} delayChildren={0.2}>
            {pillars.map(({ icon: Icon, title, text }) => (
              <RevealItem
                key={title}
                className="group rounded-2xl bg-cream-200 p-5 ring-1 ring-inset ring-transparent transition-all duration-500 ease-out-expo hover:-translate-y-1 hover:bg-white hover:shadow-[0_18px_40px_-24px_rgba(15,45,30,0.35)] hover:ring-cream-400"
              >
                <Icon aria-hidden="true" className="size-6 text-leaf-600 transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110" />
                <h3 className="mt-4 font-display text-lg font-semibold leading-tight text-forest-950">{title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-ink-soft">{text}</p>
              </RevealItem>
            ))}
          </Stagger>
        </div>

        <Reveal className="relative lg:col-span-5" delay={0.1}>
          <ParallaxImage
            src="/images/about-crop-growth.webp"
            alt="Young maize leaves covered in morning dew growing from rich soil"
            className="aspect-[4/5] rounded-[2rem] shadow-[0_40px_80px_-40px_rgba(0,23,11,0.55)] sm:aspect-[5/5] lg:aspect-[4/5]"
            sizes="(min-width: 1024px) 40vw, 100vw"
            strength={8}
          />
          {/* Floating brand card (replaces unverified stats from the design) */}
          <div className="absolute inset-x-4 bottom-4 flex items-center gap-4 rounded-2xl bg-cream-50/90 p-4 shadow-[0_20px_50px_-20px_rgba(0,23,11,0.45)] ring-1 ring-white/70 backdrop-blur-xl sm:inset-x-6 sm:bottom-6 sm:p-5">
            <span className="grid size-12 shrink-0 place-items-center rounded-full bg-leaf-200 text-forest-950">
              <Leaf aria-hidden="true" className="size-6" />
            </span>
            <div className="min-w-0">
              <p className="font-display text-lg font-semibold leading-tight text-forest-950">{company.tagline}</p>
              <p className="mt-1 text-sm text-ink-soft">{company.supportingLine}</p>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
