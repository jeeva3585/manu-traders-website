import { MessageCircle, Phone } from "lucide-react";
import { Reveal } from "@/components/animations/Reveal";
import { TextReveal } from "@/components/animations/TextReveal";
import { ButtonLink } from "@/components/ui/Button";
import { telLink, whatsappLink } from "@/lib/company";

export function ContactCTA() {
  return (
    <section aria-labelledby="cta-title" className="bg-cream-100 px-3 py-6 md:px-6 md:py-10">
      <div className="on-dark relative isolate mx-auto max-w-[1440px] overflow-hidden rounded-[2rem] bg-forest-800 text-white md:rounded-[2.5rem]">
        {/* Animated gradient lighting */}
        <div
          aria-hidden="true"
          className="absolute inset-0 -z-10 bg-[linear-gradient(120deg,#00170b_0%,#0f2d1e_30%,#005236_55%,#0f2d1e_80%,#00170b_100%)] bg-[length:220%_220%] motion-safe:animate-gradient-pan"
        />
        <div aria-hidden="true" className="absolute -left-20 -top-32 -z-10 size-[30rem] rounded-full bg-leaf-300/20 blur-3xl motion-safe:animate-sun" />
        <div aria-hidden="true" className="absolute -bottom-40 right-0 -z-10 size-[28rem] rounded-full bg-gold-500/15 blur-3xl" />

        <div className="container-site flex flex-col items-start gap-10 py-20 lg:flex-row lg:items-end lg:justify-between lg:py-28">
          <div className="max-w-3xl">
            <TextReveal
              id="cta-title"
              lines={["Looking for the Right", "Agricultural Products?"]}
              className="type-display"
              accentLines={{ 1: "text-leaf-200" }}
            />
            <Reveal delay={0.2}>
              <p className="type-lead mt-6 max-w-xl text-white/75">
                Talk to MANU Traders and find the right solution for your farm.
              </p>
            </Reveal>
          </div>
          <Reveal delay={0.3} className="flex w-full flex-col gap-3 sm:w-auto sm:flex-row">
            <ButtonLink href={telLink()} variant="light" size="lg" iconLeft={<Phone className="size-5" />}>
              Call Us
            </ButtonLink>
            <ButtonLink href={whatsappLink()} variant="accent" size="lg" iconLeft={<MessageCircle className="size-5" />}>
              WhatsApp Us
            </ButtonLink>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
