"use client";

import { motion, useReducedMotion, useScroll, useTransform, type MotionValue } from "framer-motion";
import { BadgeCheck, HandHeart, Truck } from "lucide-react";
import Image from "next/image";
import { useRef } from "react";
import { Reveal } from "@/components/animations/Reveal";
import { SectionLabel } from "@/components/ui/SectionLabel";

const lines = ["Better Inputs.", "Better Crops.", "Better Harvests."];
const promises = [
  { icon: BadgeCheck, label: "Quality Agricultural Inputs" },
  { icon: Truck, label: "Reliable Service" },
  { icon: HandHeart, label: "Trusted Support" },
];

function ScrollLine({ text, index, progress }: { text: string; index: number; progress: MotionValue<number> }) {
  const start = 0.18 + index * 0.1;
  const opacity = useTransform(progress, [start, start + 0.12], [0.18, 1]);
  const x = useTransform(progress, [start, start + 0.12], [index % 2 ? 24 : -24, 0]);
  return (
    <motion.span style={{ opacity, x }} className={index === 2 ? "block text-leaf-200" : "block"}>
      {text}
    </motion.span>
  );
}

/** Full-bleed cinematic statement with parallax, slow scale and scroll-linked text reveal. */
export function CinematicSection() {
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], reduce ? ["0%", "0%"] : ["-12%", "12%"]);
  const scale = useTransform(scrollYProgress, [0, 1], reduce ? [1.1, 1.1] : [1.25, 1.05]);

  return (
    <section
      ref={ref}
      aria-labelledby="cinematic-title"
      className="grain on-dark relative isolate flex min-h-[90svh] items-center overflow-hidden bg-forest-950 py-28 text-white lg:min-h-[110vh]"
    >
      <motion.div aria-hidden="true" className="absolute inset-0 -z-20 will-change-transform" style={{ y, scale }}>
        <Image src="/images/cinematic-harvest.webp" alt="" fill sizes="100vw" className="object-cover" />
      </motion.div>
      <div aria-hidden="true" className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_center,rgba(0,23,11,0.55)_0%,rgba(0,23,11,0.88)_70%)]" />
      <div aria-hidden="true" className="absolute inset-0 -z-10 bg-gradient-to-b from-forest-950 via-transparent to-forest-950" />

      <div className="container-site flex flex-col items-center text-center">
        <Reveal>
          <SectionLabel tone="accent">The MANU Standard</SectionLabel>
        </Reveal>
        <h2 id="cinematic-title" className="type-hero mt-8 max-w-5xl">
          {reduce ? (
            lines.map((l, i) => (
              <span key={l} className={i === 2 ? "block text-leaf-200" : "block"}>
                {l}
              </span>
            ))
          ) : (
            lines.map((l, i) => <ScrollLine key={l} text={l} index={i} progress={scrollYProgress} />)
          )}
        </h2>
        <Reveal delay={0.1}>
          <p className="type-lead mx-auto mt-8 max-w-2xl text-white/70">
            The right input at the right stage makes all the difference. We help farmers choose products that fit
            their crop, their soil and their season.
          </p>
        </Reveal>
        <Reveal delay={0.2}>
          <ul className="mt-10 flex flex-wrap justify-center gap-x-8 gap-y-3">
            {promises.map(({ icon: Icon, label }) => (
              <li key={label} className="flex items-center gap-2 text-sm font-semibold text-leaf-200">
                <Icon aria-hidden="true" className="size-4" />
                {label}
              </li>
            ))}
          </ul>
        </Reveal>
      </div>
    </section>
  );
}
