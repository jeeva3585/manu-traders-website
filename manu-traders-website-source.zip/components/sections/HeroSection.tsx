"use client";

import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { ArrowDown, ArrowRight, MessageCircle, Phone } from "lucide-react";
import Image from "next/image";
import { useRef } from "react";
import { AmbientParticles } from "@/components/animations/AmbientParticles";
import { TextReveal } from "@/components/animations/TextReveal";
import { ButtonLink } from "@/components/ui/Button";
import { company } from "@/data/company";
import { whatsappLink } from "@/lib/company";
import { ease } from "@/lib/motion";

const categories = ["Fertilizers", "Micronutrients", "Seeds", "Crop Nutrition", "Crop Protection"];

export function HeroSection() {
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const bgY = useTransform(scrollYProgress, [0, 1], ["0%", reduce ? "0%" : "22%"]);
  const contentY = useTransform(scrollYProgress, [0, 1], ["0%", reduce ? "0%" : "18%"]);
  const contentOpacity = useTransform(scrollYProgress, [0, 0.75], [1, 0]);

  const fade = (delay: number) => ({
    initial: { opacity: 0, y: 24 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.8, ease: ease.out, delay },
  });

  return (
    <section
      id="home"
      ref={ref}
      aria-labelledby="hero-title"
      className="on-dark relative isolate flex min-h-[100svh] items-end overflow-hidden bg-forest-950 text-white"
    >
      {/* Background image with parallax + slow Ken Burns zoom */}
      <motion.div className="absolute inset-0 -z-20 will-change-transform" style={{ y: bgY }}>
        <motion.div
          className="absolute inset-0"
          initial={{ scale: 1.18, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 2.4, ease: ease.out }}
        >
          <div className="absolute inset-0 motion-safe:animate-ken-burns">
            <Image
              src="/images/hero-farm.webp"
              alt="Aerial view of green paddy fields and farmland in Tamil Nadu at sunrise"
              fill
              preload
              fetchPriority="high"
              sizes="100vw"
              className="object-cover"
            />
          </div>
        </motion.div>
      </motion.div>

      {/* Readability overlays: deep green wash + bottom fade */}
      <div aria-hidden="true" className="absolute inset-0 -z-10 bg-[linear-gradient(100deg,rgba(0,23,11,0.92)_0%,rgba(0,23,11,0.7)_42%,rgba(4,32,15,0.35)_100%)]" />
      <div aria-hidden="true" className="absolute inset-x-0 bottom-0 -z-10 h-2/5 bg-gradient-to-t from-forest-950 via-forest-950/60 to-transparent" />

      {/* Soft sunlight */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-[10%] -top-[20%] -z-10 size-[70vw] max-w-[1100px] rounded-full bg-[radial-gradient(circle,rgba(244,184,96,0.32)_0%,rgba(244,184,96,0.08)_40%,transparent_70%)] motion-safe:animate-sun"
      />
      <AmbientParticles className="-z-10" />

      <motion.div style={{ y: contentY, opacity: contentOpacity }} className="container-site w-full pb-10 pt-36 md:pb-14">
        <motion.p
          {...fade(0.3)}
          className="type-eyebrow inline-flex items-center gap-2.5 rounded-full bg-white/8 px-4 py-2.5 text-leaf-200 ring-1 ring-inset ring-white/12 backdrop-blur-md"
        >
          <span aria-hidden="true" className="relative flex size-2">
            <span className="absolute inset-0 rounded-full bg-leaf-200 motion-safe:animate-soft-pulse" />
            <span className="relative size-2 rounded-full bg-leaf-200" />
          </span>
          Fertilizers &amp; Farm Inputs · {company.region}
        </motion.p>

        <TextReveal
          as="h1"
          id="hero-title"
          trigger="mount"
          delay={0.45}
          lines={["Growing Together", "With Farmers."]}
          accentLines={{ 1: "text-leaf-200" }}
          className="type-hero mt-7 max-w-5xl"
        />

        <motion.p {...fade(1.05)} className="type-lead mt-7 max-w-xl text-white/75">
          Reliable agricultural inputs, trusted products and dependable support for better farming.
        </motion.p>

        <motion.div {...fade(1.25)} className="mt-9 flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center">
          <ButtonLink href="/#products" size="lg" icon={<ArrowRight className="size-5" />}>
            Explore Products
          </ButtonLink>
          <ButtonLink href="/#contact" size="lg" variant="ghost-light" iconLeft={<Phone className="size-[1.1rem]" />}>
            Contact Us
          </ButtonLink>
          <a
            href={whatsappLink()}
            target="_blank"
            rel="noopener noreferrer"
            className="group inline-flex h-14 items-center gap-2.5 rounded-full px-3 font-semibold text-white/85 transition-colors hover:text-leaf-200 sm:px-4"
          >
            <span className="grid size-9 place-items-center rounded-full bg-leaf-600 text-white transition-transform duration-300 group-hover:scale-105">
              <MessageCircle aria-hidden="true" className="size-[1.1rem]" />
            </span>
            WhatsApp Us
          </a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.6 }}
          className="mt-16 flex items-end justify-between gap-6 border-t border-white/12 pt-6 md:mt-24"
        >
          <ul className="flex flex-wrap gap-x-5 gap-y-2 text-[0.7rem] font-semibold uppercase tracking-[0.16em] text-white/60">
            {categories.map((c, i) => (
              <li key={c} className="flex items-center gap-5">
                {i > 0 ? <span aria-hidden="true" className="size-1 rounded-full bg-leaf-200/70" /> : null}
                {c}
              </li>
            ))}
          </ul>
          <a
            href="#about"
            className="hidden shrink-0 items-center gap-3 text-[0.7rem] font-semibold uppercase tracking-[0.18em] text-white/70 transition-colors hover:text-white md:inline-flex"
          >
            Scroll to Explore
            <span className="relative grid h-11 w-7 place-items-start justify-center overflow-hidden rounded-full ring-1 ring-white/30">
              <ArrowDown aria-hidden="true" className="mt-2 size-3.5 motion-safe:animate-scroll-cue" />
            </span>
          </a>
        </motion.div>
      </motion.div>
    </section>
  );
}
