import { ArrowRight, TreePalm } from "lucide-react";
import { ParallaxImage } from "@/components/animations/ParallaxImage";
import { Reveal, RevealItem, Stagger } from "@/components/animations/Reveal";
import { ButtonLink } from "@/components/ui/Button";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { coconutCare } from "@/data/coconut";
import { whatsappLink } from "@/lib/company";
import { cn } from "@/lib/utils";

export function CoconutSection() {
  if (!coconutCare.enabled) return null;
  const [grove, root] = coconutCare.gallery;

  return (
    <section aria-labelledby="coconut-title" className="section-y relative bg-cream-100">
      <div className="container-site">
        <SectionHeader
          id="coconut-title"
          eyebrow={coconutCare.eyebrow}
          eyebrowIcon={<TreePalm aria-hidden="true" className="size-3.5" />}
          title={[coconutCare.title]}
          description={coconutCare.description}
          aside={
            <ButtonLink
              href={whatsappLink("Hello MANU Traders, I would like to know about coconut care and root feeding products.")}
              iconLeft={<TreePalm className="size-5" />}
            >
              {coconutCare.cta}
            </ButtonLink>
          }
        />

        <div className="mt-14 grid gap-5 lg:grid-cols-12 lg:gap-6">
          {[grove, root].map((g, i) => (
            <Reveal
              key={g.image}
              delay={i * 0.12}
              className={cn(
                "group relative overflow-hidden rounded-[2rem] shadow-[0_40px_80px_-50px_rgba(0,23,11,0.6)]",
                i === 0 ? "lg:col-span-7" : "lg:col-span-5",
              )}
            >
              <ParallaxImage
                src={g.image}
                alt={g.alt}
                className="aspect-[4/3] lg:aspect-auto lg:h-[30rem]"
                sizes={i === 0 ? "(min-width: 1024px) 58vw, 100vw" : "(min-width: 1024px) 42vw, 100vw"}
                strength={7}
              />
              <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-forest-950/80 via-forest-950/10 to-transparent" />
              <p className="type-eyebrow absolute left-4 top-4 rounded-full bg-forest-950/70 px-3.5 py-2 text-leaf-200 backdrop-blur-md">
                {g.chip}
              </p>
              <div
                className={cn(
                  "absolute inset-x-4 bottom-4 rounded-2xl p-5 backdrop-blur-xl sm:inset-x-6 sm:bottom-6",
                  i === 0 ? "bg-cream-50/90 text-forest-950" : "bg-forest-950/80 text-white ring-1 ring-white/10",
                )}
              >
                <p className="font-display text-lg font-semibold">{g.cardTitle}</p>
                <p className={cn("mt-1 text-sm", i === 0 ? "text-ink-soft" : "text-white/70")}>{g.cardText}</p>
              </div>
            </Reveal>
          ))}
        </div>

        <Stagger className="mt-6 grid gap-5 md:grid-cols-3 lg:gap-6" stagger={0.12}>
          {coconutCare.items.map(({ icon: Icon, title, text, tag }) => (
            <RevealItem
              key={title}
              className="group flex flex-col rounded-[1.75rem] bg-cream-200 p-7 ring-1 ring-inset ring-cream-400/80 transition-all duration-500 ease-out-expo hover:-translate-y-1 hover:bg-white hover:shadow-[0_24px_50px_-30px_rgba(0,23,11,0.4)]"
            >
              <span className="grid size-12 place-items-center rounded-xl bg-leaf-200 text-forest-950 transition-transform duration-500 group-hover:-rotate-6">
                <Icon aria-hidden="true" className="size-5" />
              </span>
              <h3 className="type-h3 mt-6 text-forest-950">{title}</h3>
              <p className="mt-3 leading-relaxed text-ink-muted">{text}</p>
              <p className="mt-auto flex items-center gap-2 pt-6 text-xs font-bold uppercase tracking-[0.12em] text-leaf-600">
                {tag}
                <ArrowRight aria-hidden="true" className="size-3.5 transition-transform group-hover:translate-x-1" />
              </p>
            </RevealItem>
          ))}
        </Stagger>
      </div>
    </section>
  );
}
