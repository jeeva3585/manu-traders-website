"use client";

import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { Sprout } from "lucide-react";
import Image from "next/image";
import { useRef } from "react";
import { TextReveal } from "@/components/animations/TextReveal";

/** "When Farmers Grow, Communities Grow." — high-impact brand statement. */
export function ParallaxBrandSection() {
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], reduce ? ["0%", "0%"] : ["-15%", "15%"]);
  const sunX = useTransform(scrollYProgress, [0, 1], reduce ? ["0%", "0%"] : ["-10%", "15%"]);

  return (
    <section
      ref={ref}
      aria-labelledby="brand-title"
      className="grain on-dark relative isolate flex min-h-[80svh] items-center overflow-hidden bg-forest-950 py-28 text-white"
    >
      <motion.div aria-hidden="true" className="absolute -inset-y-[18%] inset-x-0 -z-20 will-change-transform" style={{ y }}>
        <Image src="/images/communities-grow.webp" alt="" fill sizes="100vw" className="object-cover" />
      </motion.div>
      <div aria-hidden="true" className="absolute inset-0 -z-10 bg-[linear-gradient(90deg,rgba(0,23,11,0.92)_0%,rgba(0,23,11,0.6)_55%,rgba(0,23,11,0.35)_100%)]" />
      <motion.div
        aria-hidden="true"
        style={{ x: sunX }}
        className="pointer-events-none absolute -top-1/3 right-0 -z-10 size-[60vw] max-w-[900px] rounded-full bg-[radial-gradient(circle,rgba(244,184,96,0.35)_0%,rgba(244,184,96,0.06)_45%,transparent_70%)]"
      />

      <div className="container-site">
        <Sprout aria-hidden="true" className="size-10 text-leaf-200" strokeWidth={1.6} />
        <TextReveal
          id="brand-title"
          lines={["When Farmers Grow,", "Communities Grow."]}
          accentLines={{ 1: "text-leaf-200" }}
          className="type-hero mt-6 max-w-5xl"
        />
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.6 }}
          transition={{ duration: 0.9, delay: 0.6 }}
          className="type-lead mt-8 max-w-xl text-white/70"
        >
          Every healthy harvest strengthens a family, a village and the local economy. That is why we grow together.
        </motion.p>
      </div>
    </section>
  );
}
