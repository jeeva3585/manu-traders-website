import { ArrowRight, CalendarCheck, Sparkles } from "lucide-react";
import { ParallaxImage } from "@/components/animations/ParallaxImage";
import { Reveal, RevealItem, Stagger } from "@/components/animations/Reveal";
import { ButtonLink } from "@/components/ui/Button";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { SectionLabel } from "@/components/ui/SectionLabel";
import { featuredService, services, type Service } from "@/data/services";
import { whatsappLink } from "@/lib/company";

function ServiceCard({ service, index }: { service: Service; index: number }) {
  const Icon = service.icon;
  return (
    <article className="group relative flex h-full flex-col rounded-[1.75rem] bg-cream-50 p-7 ring-1 ring-inset ring-cream-400/70 transition-all duration-500 ease-out-expo hover:-translate-y-1 hover:bg-white hover:shadow-[0_26px_56px_-32px_rgba(0,23,11,0.42)]">
      <div className="flex items-center justify-between">
        <span className="grid size-12 place-items-center rounded-xl bg-cream-300 text-leaf-600 transition-colors duration-500 group-hover:bg-leaf-200 group-hover:text-forest-950">
          <Icon aria-hidden="true" className="size-5" />
        </span>
        <span aria-hidden="true" className="font-display text-sm font-semibold text-ink-soft/60">
          {String(index + 1).padStart(2, "0")}
        </span>
      </div>
      <h3 className="type-h3 mt-6 text-forest-950">{service.title}</h3>
      <p className="mt-3 leading-relaxed text-ink-muted">{service.text}</p>
      <p className="mt-auto flex items-center gap-2 pt-6 text-sm font-semibold text-leaf-600">
        {service.tag}
        <ArrowRight aria-hidden="true" className="size-4 transition-transform duration-300 group-hover:translate-x-1" />
      </p>
    </article>
  );
}

export function ServicesSection() {
  const active = services.filter((s) => s.enabled);

  return (
    <section id="services" aria-labelledby="services-title" className="section-y relative bg-cream-100">
      <div className="container-site">
        <SectionHeader
          id="services-title"
          eyebrow="Our Services"
          eyebrowIcon={<Sparkles aria-hidden="true" className="size-3.5" />}
          title={["More Than Agricultural Products"]}
          description="Supply, guidance and support that make each season a little easier for farmers."
        />

        {/* Featured service band (Stitch layout) */}
        <Reveal className="on-dark mt-14 overflow-hidden rounded-[2rem] bg-forest-950 text-white shadow-[0_40px_80px_-40px_rgba(0,23,11,0.7)] lg:mt-16">
          <div className="grid lg:grid-cols-12">
            <div className="flex flex-col justify-center p-8 sm:p-10 lg:col-span-5 lg:p-14">
              <SectionLabel tone="glass">{featuredService.eyebrow}</SectionLabel>
              <h3 className="mt-6 font-display text-[1.9rem] font-semibold leading-[1.1] tracking-[-0.02em] sm:text-4xl">
                {featuredService.title}
              </h3>
              <p className="mt-5 leading-relaxed text-white/70">{featuredService.text}</p>
              <div className="mt-8">
                <ButtonLink
                  href={whatsappLink("Hello MANU Traders, I would like guidance on products for my crop.")}
                  icon={<CalendarCheck className="size-[1.1rem]" />}
                >
                  {featuredService.cta}
                </ButtonLink>
              </div>
            </div>
            <div className="relative min-h-[18rem] lg:col-span-7 lg:min-h-[26rem]">
              <div className="absolute inset-0 lg:inset-y-3 lg:right-3">
                <ParallaxImage
                  src={featuredService.image}
                  alt={featuredService.imageAlt}
                  className="size-full lg:rounded-[1.6rem]"
                  sizes="(min-width: 1024px) 58vw, 100vw"
                  strength={6}
                />
              </div>
              <p className="absolute bottom-6 right-6 rounded-full bg-forest-950/75 px-4 py-2 text-xs font-semibold text-leaf-200 backdrop-blur-md">
                {featuredService.chip}
              </p>
            </div>
          </div>
        </Reveal>

        <Stagger className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 lg:gap-6 xl:grid-cols-5" stagger={0.1}>
          {active.map((service, i) => (
            <RevealItem key={service.title} className="h-full">
              <ServiceCard service={service} index={i} />
            </RevealItem>
          ))}
        </Stagger>
      </div>
    </section>
  );
}
