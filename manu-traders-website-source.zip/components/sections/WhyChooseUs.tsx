"use client";

import { motion } from "framer-motion";
import { RevealItem, Stagger } from "@/components/animations/Reveal";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { benefits } from "@/data/benefits";
import { ease } from "@/lib/motion";

export function WhyChooseUs() {
  return (
    <section id="why-us" aria-labelledby="why-title" className="section-y relative bg-cream-100">
      <div className="container-site">
        <SectionHeader
          id="why-title"
          eyebrow="Why MANU Traders"
          title={["Why Farmers Trust Us"]}
          description="Built on genuine products, honest advice and a commitment to the farmers we serve."
        />

        <Stagger className="mt-14 grid gap-5 sm:grid-cols-2 lg:mt-16 lg:grid-cols-4 lg:gap-6" stagger={0.14}>
          {benefits.map(({ icon: Icon, title, text, tag }, i) => (
            <RevealItem key={title} className="h-full">
              <motion.article
                whileHover="hover"
                className="group relative flex h-full flex-col overflow-hidden rounded-[1.75rem] bg-cream-200 p-7 transition-[background-color,box-shadow] duration-500 ease-out-expo hover:bg-white hover:shadow-[0_28px_60px_-34px_rgba(0,23,11,0.45)]"
              >
                <span aria-hidden="true" className="absolute right-6 top-5 font-display text-5xl font-bold text-forest-950/[0.05]">
                  0{i + 1}
                </span>
                {/* Animated icon: tile lifts and the icon draws a gentle rotation on hover */}
                <motion.span
                  variants={{ hover: { y: -4, rotate: -6 } }}
                  transition={{ duration: 0.45, ease: ease.out }}
                  className="relative grid size-14 place-items-center rounded-2xl bg-leaf-200 text-forest-950"
                >
                  <motion.span
                    initial={{ scale: 0.4, opacity: 0 }}
                    whileInView={{ scale: 1, opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, ease: ease.out, delay: 0.25 + i * 0.12 }}
                  >
                    <Icon aria-hidden="true" className="size-6" strokeWidth={2} />
                  </motion.span>
                </motion.span>
                <h3 className="type-h3 mt-7 text-forest-950">{title}</h3>
                <p className="mt-3 leading-relaxed text-ink-muted">{text}</p>
                <p className="mt-auto pt-8 text-xs font-bold uppercase tracking-[0.12em] text-leaf-600">{tag}</p>
                <span
                  aria-hidden="true"
                  className="absolute inset-x-7 bottom-0 h-[3px] origin-left scale-x-0 rounded-full bg-leaf-600 transition-transform duration-500 ease-out-expo group-hover:scale-x-100"
                />
              </motion.article>
            </RevealItem>
          ))}
        </Stagger>
      </div>
    </section>
  );
}
