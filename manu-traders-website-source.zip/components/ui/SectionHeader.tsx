import type { ReactNode } from "react";
import { Reveal } from "@/components/animations/Reveal";
import { TextReveal } from "@/components/animations/TextReveal";
import { SectionLabel } from "@/components/ui/SectionLabel";
import { cn } from "@/lib/utils";

type SectionHeaderProps = {
  id?: string;
  eyebrow: string;
  eyebrowIcon?: ReactNode;
  title: string[];
  description?: string;
  align?: "left" | "center";
  tone?: "light" | "dark";
  aside?: ReactNode;
  className?: string;
};

/** Eyebrow + masked heading + lead paragraph, consistent across sections. */
export function SectionHeader({
  id,
  eyebrow,
  eyebrowIcon,
  title,
  description,
  align = "left",
  tone = "light",
  aside,
  className,
}: SectionHeaderProps) {
  const centered = align === "center";
  const dark = tone === "dark";

  return (
    <div
      className={cn(
        "flex flex-col gap-8",
        Boolean(aside) && "lg:flex-row lg:items-end lg:justify-between",
        centered && "items-center text-center",
        className,
      )}
    >
      <div className={cn("flex max-w-3xl flex-col gap-5", centered && "items-center")}>
        <Reveal>
          <SectionLabel tone={dark ? "glass" : "light"} icon={eyebrowIcon}>
            {eyebrow}
          </SectionLabel>
        </Reveal>
        <TextReveal
          id={id}
          lines={title}
          className={cn("type-h2", dark ? "text-white" : "text-forest-950")}
        />
        {description ? (
          <Reveal delay={0.15}>
            <p className={cn("type-lead max-w-2xl", dark ? "text-white/70" : "text-ink-muted")}>{description}</p>
          </Reveal>
        ) : null}
      </div>
      {aside ? <Reveal delay={0.2}>{aside}</Reveal> : null}
    </div>
  );
}
