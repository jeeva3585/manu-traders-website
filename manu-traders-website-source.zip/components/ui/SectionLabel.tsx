import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

type Tone = "light" | "dark" | "accent" | "glass";

const tones: Record<Tone, string> = {
  light: "bg-cream-300 text-leaf-600",
  dark: "bg-forest-950 text-leaf-200",
  accent: "bg-leaf-200 text-forest-950",
  glass: "bg-white/8 text-leaf-200 ring-1 ring-inset ring-white/12 backdrop-blur-md",
};

/** Small pill eyebrow used above section headings (Stitch pattern). */
export function SectionLabel({
  children,
  tone = "light",
  icon,
  className,
}: {
  children: ReactNode;
  tone?: Tone;
  icon?: ReactNode;
  className?: string;
}) {
  return (
    <p
      className={cn(
        "type-eyebrow inline-flex items-center gap-2 rounded-full px-3.5 py-2",
        tones[tone],
        className,
      )}
    >
      {icon ?? <span aria-hidden="true" className="size-1.5 rounded-full bg-current" />}
      <span>{children}</span>
    </p>
  );
}
