import Link from "next/link";
import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { cn } from "@/lib/utils";

type Variant = "accent" | "dark" | "ghost-light" | "ghost-dark" | "light";
type Size = "md" | "lg" | "sm";

const variants: Record<Variant, string> = {
  // Fresh leaf accent — primary CTA from the Stitch design
  accent:
    "bg-leaf-200 text-forest-950 hover:bg-leaf-300 shadow-[0_8px_24px_-12px_rgba(0,108,73,0.55)]",
  dark: "bg-forest-950 text-white hover:bg-forest-800",
  light: "bg-white text-forest-950 hover:bg-cream-200",
  // Outline/ghost on dark backgrounds
  "ghost-light":
    "bg-white/8 text-white ring-1 ring-inset ring-white/20 backdrop-blur-md hover:bg-white/14 hover:ring-white/35",
  // Outline/ghost on light backgrounds
  "ghost-dark": "bg-transparent text-forest-950 ring-1 ring-inset ring-forest-950/15 hover:bg-forest-950/5",
};

const sizes: Record<Size, string> = {
  sm: "h-10 px-4 text-sm gap-2",
  md: "h-12 px-6 text-[0.9375rem] gap-2.5",
  lg: "h-14 px-7 text-base gap-3",
};

const base =
  "group/btn relative inline-flex select-none items-center justify-center whitespace-nowrap rounded-full font-semibold tracking-[0.005em] transition-[background-color,box-shadow,color,transform] duration-300 ease-out-expo active:scale-[0.98] disabled:pointer-events-none disabled:opacity-60";

type CommonProps = {
  variant?: Variant;
  size?: Size;
  icon?: ReactNode;
  iconLeft?: ReactNode;
  className?: string;
  children: ReactNode;
};

function Content({ icon, iconLeft, children }: Pick<CommonProps, "icon" | "iconLeft" | "children">) {
  return (
    <>
      {iconLeft ? <span className="shrink-0" aria-hidden="true">{iconLeft}</span> : null}
      <span>{children}</span>
      {icon ? (
        <span
          className="shrink-0 transition-transform duration-300 ease-out-expo group-hover/btn:translate-x-0.5"
          aria-hidden="true"
        >
          {icon}
        </span>
      ) : null}
    </>
  );
}

type ButtonLinkProps = CommonProps &
  Omit<ComponentPropsWithoutRef<"a">, "className" | "children"> & {
    href: string;
    external?: boolean;
  };

/** Link styled as a button. External links open in a new tab safely. */
export function ButtonLink({
  href,
  external,
  variant = "accent",
  size = "md",
  icon,
  iconLeft,
  className,
  children,
  ...rest
}: ButtonLinkProps) {
  const classes = cn(base, variants[variant], sizes[size], className);
  const isExternal = external ?? /^(https?:|mailto:|tel:)/.test(href);

  if (isExternal) {
    const newTab = href.startsWith("http");
    return (
      <a
        href={href}
        className={classes}
        {...(newTab ? { target: "_blank", rel: "noopener noreferrer" } : {})}
        {...rest}
      >
        <Content icon={icon} iconLeft={iconLeft}>
          {children}
        </Content>
      </a>
    );
  }

  return (
    <Link href={href} className={classes} {...rest}>
      <Content icon={icon} iconLeft={iconLeft}>
        {children}
      </Content>
    </Link>
  );
}

type ButtonProps = CommonProps & Omit<ComponentPropsWithoutRef<"button">, "className" | "children">;

export function Button({
  variant = "accent",
  size = "md",
  icon,
  iconLeft,
  className,
  children,
  type = "button",
  ...rest
}: ButtonProps) {
  return (
    <button type={type} className={cn(base, variants[variant], sizes[size], className)} {...rest}>
      <Content icon={icon} iconLeft={iconLeft}>
        {children}
      </Content>
    </button>
  );
}
