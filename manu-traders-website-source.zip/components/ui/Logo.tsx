import Link from "next/link";
import { cn } from "@/lib/utils";

/**
 * MANU Traders emblem — two leaves, a stem and a sunlit seed,
 * redrawn as crisp SVG from the Stitch "Emblem & Wordmark".
 * Replace with the official logo file when supplied.
 */
export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={cn("shrink-0", className)} aria-hidden="true" focusable="false">
      <path d="M22.6 41.5C14 37.6 6.8 27.8 4.5 19.2c7.6 2 14.8 9.6 18.1 22.3Z" fill="#3aa982" />
      <path d="M25.4 41.5c3-11.5 10.7-23.6 19-27-1.7 10.6-9.3 22.7-19 27Z" fill="#2cc48a" />
      <rect x="22.6" y="17.5" width="2.8" height="25" rx="1.4" fill="#006c49" />
      <circle cx="24" cy="10.5" r="3.6" fill="#f2a516" />
    </svg>
  );
}

export function Logo({
  tone = "dark",
  className,
  showTagline = true,
}: {
  tone?: "dark" | "light";
  className?: string;
  showTagline?: boolean;
}) {
  const light = tone === "light";
  return (
    <Link
      href="/#home"
      aria-label="MANU Traders — home"
      className={cn("group inline-flex items-center gap-2.5 rounded-lg", className)}
    >
      <LogoMark className="size-9 transition-transform duration-500 ease-out-expo group-hover:-rotate-6" />
      <span className="flex flex-col leading-none">
        <span
          className={cn(
            "whitespace-nowrap font-display text-[1.15rem] font-bold tracking-[0.02em] transition-colors duration-300",
            light ? "text-white" : "text-forest-950",
          )}
        >
          MANU <span className={light ? "text-leaf-200" : "text-leaf-600"}>TRADERS</span>
        </span>
        {showTagline ? (
          <span
            className={cn(
              "mt-1 hidden whitespace-nowrap text-[0.6rem] font-semibold uppercase tracking-[0.2em] transition-colors duration-300 min-[400px]:block",
              light ? "text-white/60" : "text-ink-soft",
            )}
          >
            Agri Inputs · Tamil Nadu
          </span>
        ) : null}
      </span>
    </Link>
  );
}
